plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.banksms"
    compileSdk = 34
    defaultConfig { applicationId = "com.example.banksms"; minSdk = 26; targetSdk = 34; versionCode = 4; versionName = "2.1" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
