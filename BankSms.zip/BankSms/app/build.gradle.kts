plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.banksms"
    compileSdk = 34
    defaultConfig { applicationId = "com.example.banksms"; minSdk = 26; targetSdk = 34; versionCode = 6; versionName = "4.0" }
    signingConfigs {
        create("main") {
            storeFile = file("banksms.jks"); storePassword = "banksms2026"
            keyAlias = "banksms"; keyPassword = "banksms2026"
        }
    }
    buildTypes {
        getByName("release") { signingConfig = signingConfigs.getByName("main"); isMinifyEnabled = false }
        getByName("debug") { signingConfig = signingConfigs.getByName("main") }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
