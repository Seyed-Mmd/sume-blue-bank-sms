package com.example.banksms

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.time.LocalDate
import java.util.zip.ZipInputStream

// بازیابی تراکنش‌ها از فایل پشتیبانِ خروجی برنامه (CSV، متن چسبانده‌شده یا Excel با پسوند xlsx)
// ستون‌ها: تاریخ، نوع، مبلغ (تومان)، دسته، بانک، توضیح
object Backup {
    class Result(val added: Int, val existed: Int, val bad: Int, val newCats: Int)

    const val NO_CAT = "بدون دسته"

    // ───────────── خواندن فایل ─────────────
    fun readTable(bytes: ByteArray): List<List<String>> {
        if (bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) return parseXlsx(bytes)
        if (bytes.size > 4 && bytes[0] == 0xD0.toByte() && bytes[1] == 0xCF.toByte())
            throw IllegalArgumentException("فایل Excel قدیمی (xls) پشتیبانی نمی‌شود؛ در Excel با «Save As» آن را به xlsx یا CSV تبدیل کن")
        return parseCsv(decode(bytes))
    }

    private fun decode(b: ByteArray): String {
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString().removePrefix("\uFEFF")
        } catch (e: Exception) {
            String(b, charset("windows-1256"))   // CSV ذخیره‌شده توسط Excel فارسی ویندوز
        }
    }

    fun parseCsv(text: String): List<List<String>> {
        val t = text.removePrefix("\uFEFF")
        val first = t.lineSequence().firstOrNull { it.isNotBlank() } ?: return emptyList()
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> first.count { it == d } } ?: ','
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>(); val cell = StringBuilder(); var q = false; var i = 0
        fun endCell() { row.add(cell.toString()); cell.setLength(0) }
        fun endRow() { endCell(); if (row.any { it.isNotBlank() }) rows.add(row); row = mutableListOf() }
        while (i < t.length) {
            val c = t[i]
            when {
                q && c == '"' && i + 1 < t.length && t[i + 1] == '"' -> { cell.append('"'); i++ }
                c == '"' -> q = !q
                !q && c == delim -> endCell()
                !q && c == '\n' -> endRow()
                !q && c == '\r' -> {}
                else -> cell.append(c)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) endRow()
        return rows
    }

    // ───────────── xlsx (بدون کتابخانه اضافه) ─────────────
    private fun parseXlsx(bytes: ByteArray): List<List<String>> {
        var shared: ByteArray? = null
        val sheets = sortedMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "xl/sharedStrings.xml") shared = z.readBytes()
                else if (e.name.startsWith("xl/worksheets/") && e.name.endsWith(".xml")) sheets[e.name] = z.readBytes()
                e = z.nextEntry
            }
        }
        val sheet = sheets["xl/worksheets/sheet1.xml"] ?: sheets.values.firstOrNull()
            ?: throw IllegalArgumentException("برگه‌ای در فایل Excel پیدا نشد")
        val strings = shared?.let { parseShared(it) } ?: emptyList()
        return parseSheet(sheet, strings)
    }

    private fun parseShared(b: ByteArray): List<String> {
        val p = Xml.newPullParser(); p.setInput(ByteArrayInputStream(b), null)
        val out = mutableListOf<String>(); var sb: StringBuilder? = null; var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) { "si" -> sb = StringBuilder(); "t" -> inT = true }
                XmlPullParser.TEXT -> if (inT) sb?.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) { "t" -> inT = false; "si" -> { out.add(sb?.toString() ?: ""); sb = null } }
            }
            ev = p.next()
        }
        return out
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) { if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break }
        return n - 1
    }

    private fun parseSheet(b: ByteArray, strings: List<String>): List<List<String>> {
        val p = Xml.newPullParser(); p.setInput(ByteArrayInputStream(b), null)
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        var col = 0; var type = ""; var v = StringBuilder(); var inV = false; var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { col = p.getAttributeValue(null, "r")?.let { colIndex(it) } ?: row.size
                        type = p.getAttributeValue(null, "t") ?: ""; v = StringBuilder() }
                    "v" -> inV = true
                    "t" -> inT = true
                }
                XmlPullParser.TEXT -> if (inV || inT) v.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> {
                        val raw = v.toString()
                        val value = if (type == "s") strings.getOrNull(raw.trim().toIntOrNull() ?: -1) ?: "" else raw
                        while (row.size < col) row.add("")
                        if (row.size == col) row.add(value) else row[col] = value
                    }
                    "row" -> if (row.any { it.isNotBlank() }) rows.add(row)
                }
            }
            ev = p.next()
        }
        return rows
    }

    // ───────────── تبدیل مقدارها ─────────────
    private fun typeOf(s: String): String {
        val t = Parser.norm(s).lowercase()
        return when {
            "واریز" in t || "deposit" in t || "درآمد" in t -> "deposit"
            "اینترنتی" in t || "purchase" in t -> "purchase"
            else -> "withdraw"
        }
    }

    private fun validYear(y: Int) = y in 1300..1500

    // تاریخ شمسی؛ اگر Excel آن را به عدد/تاریخ میلادی تبدیل کرده باشد هم خوانده می‌شود
    private fun dateOf(raw: String): Long? {
        val s = Parser.norm(raw).trim().split(' ', 'T').firstOrNull { it.isNotEmpty() } ?: return null
        val p = s.split('/', '-', '.').mapNotNull { it.trim().toIntOrNull() }
        if (p.size == 3) {
            if (validYear(p[0])) return Dates.parseDay("${p[0]}/${p[1]}/${p[2]}")
            if (validYear(p[2])) return Dates.parseDay("${p[2]}/${p[0]}/${p[1]}")   // ماه/روز/سال
        }
        val serial = s.toDoubleOrNull()
        if (serial != null && serial > 1000) {
            val d = LocalDate.of(1899, 12, 30).plusDays(serial.toLong())
            if (validYear(d.year)) return Dates.parseDay("${d.year}/${d.monthValue}/${d.dayOfMonth}")
        }
        return null
    }

    private fun amountOf(raw: String): Long? {
        val s = Parser.norm(raw).replace(",", "").replace(" ", "").trim()
        val d = s.toDoubleOrNull() ?: return null
        return Math.abs(d).toLong().takeIf { it > 0 }
    }

    private fun key(day: String, type: String, amount: Long, desc: String) =
        "$day|$type|$amount|${Parser.norm(desc).trim()}"

    // ───────────── افزودن به پایگاه داده (بدون تکرار) ─────────────
    fun import(db: Db, table: List<List<String>>): Result {
        val have = HashMap<String, Int>()
        db.done().forEach { have.merge(key(Dates.fmtDay(it.time), it.type, it.amount, it.desc.ifEmpty { it.merchant }), 1, Int::plus) }
        val cats = db.cats().toMutableSet()
        var added = 0; var existed = 0; var bad = 0; var newCats = 0
        table.forEachIndexed { idx, r ->
            fun c(i: Int) = r.getOrNull(i)?.trim().orEmpty()
            val day = dateOf(c(0))
            val amount = amountOf(c(2))
            if (day == null || amount == null) {
                if (idx != 0) bad++          // ردیف اول معمولاً عنوان ستون‌هاست
                return@forEachIndexed
            }
            val type = typeOf(c(1))
            val cat = c(3).let { if (it == NO_CAT) "" else it }
            val bank = c(4); val desc = c(5)
            val k = key(Dates.fmtDay(day), type, amount, desc)
            val n = have[k] ?: 0
            if (n > 0) { have[k] = n - 1; existed++; return@forEachIndexed }
            if (cat.isNotEmpty() && cats.add(cat)) { db.addCat(cat); newCats++ }
            db.addManual(type, amount, desc, cat, bank, day + 12 * 3_600_000L)
            added++
        }
        return Result(added, existed, bad, newCats)
    }
}
