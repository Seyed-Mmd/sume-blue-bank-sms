package com.example.banksms

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

// نمودار دایره‌ای (دونات) برای دسته‌ها
class Donut(c: Context, private val data: List<Pair<String, Long>>) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    override fun onDraw(cv: Canvas) {
        val total = data.sumOf { it.second }.toFloat()
        if (total <= 0f) return
        val sw = width * 0.17f
        paint.strokeWidth = sw
        rect.set(sw / 2, sw / 2, width - sw / 2, height - sw / 2)
        var start = -90f
        data.forEachIndexed { i, d ->
            val sweep = d.second / total * 360f
            paint.color = C.palette[i % C.palette.size]
            cv.drawArc(rect, start, maxOf(sweep - 1.5f, 0.5f), false, paint)
            start += sweep
        }
    }
}

// نمودار میله‌ای روند هزینه
class DayBars(c: Context, private val values: List<Long>) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    override fun onDraw(cv: Canvas) {
        if (values.isEmpty()) return
        val top = values.maxOrNull() ?: 0L
        val max = maxOf(top, 1L).toFloat()
        val n = values.size
        val slot = width.toFloat() / n
        val pad = slot * 0.18f
        val d = resources.displayMetrics.density
        val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
        values.forEachIndexed { i, v ->
            val h = maxOf(v / max * (height - 3 * d), 3 * d)
            val idx = if (rtl) n - 1 - i else i
            paint.color = C.primary
            paint.alpha = if (v == top && top > 0L) 255 else 140
            rect.set(idx * slot + pad, height - h, idx * slot + slot - pad, height.toFloat())
            cv.drawRoundRect(rect, 4 * d, 4 * d, paint)
        }
    }
}
