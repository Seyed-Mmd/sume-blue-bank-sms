package com.example.banksms

import android.icu.text.SimpleDateFormat
import android.icu.util.Calendar
import android.icu.util.ULocale
import java.util.Date

object Dates {
    private val fa = ULocale("fa_IR@calendar=persian")
    private fun cal(): Calendar = Calendar.getInstance(fa)
    const val DAY = 86_400_000L

    fun lastDays(n: Int): Pair<String, String> {
        val c = cal(); val today = fmtDay(c.timeInMillis)
        c.add(Calendar.DATE, -(n - 1))
        return Pair(fmtDay(c.timeInMillis), today)
    }

    fun fmtDay(ms: Long): String = SimpleDateFormat("yyyy/MM/dd", fa).format(Date(ms))
    fun fmtTime(ms: Long): String = SimpleDateFormat("yyyy/MM/dd  HH:mm", fa).format(Date(ms))

    fun parseDay(s: String): Long? {
        val p = Parser.norm(s).trim().split('/', '-', '.').mapNotNull { it.trim().toIntOrNull() }
        if (p.size != 3) return null
        return cal().apply { clear(); set(p[0], p[1] - 1, p[2]) }.timeInMillis
    }

    fun thisMonth(): Pair<String, String> {
        val c = cal(); val today = fmtDay(c.timeInMillis)
        c.set(Calendar.DAY_OF_MONTH, 1)
        return Pair(fmtDay(c.timeInMillis), today)
    }

    fun prevMonth(): Pair<String, String> {
        val c = cal()
        c.set(Calendar.DAY_OF_MONTH, 1); c.add(Calendar.MONTH, -1)
        val first = fmtDay(c.timeInMillis)
        c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH))
        return Pair(first, fmtDay(c.timeInMillis))
    }

    fun last7(): Pair<String, String> {
        val c = cal(); val today = fmtDay(c.timeInMillis)
        c.add(Calendar.DATE, -6)
        return Pair(fmtDay(c.timeInMillis), today)
    }

    fun monthRange(): Pair<Long, Long> {
        val c = cal()
        c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        val start = c.timeInMillis
        c.add(Calendar.MONTH, 1)
        return Pair(start, c.timeInMillis)
    }
}
