package com.example.banksms

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// status: 0 = جدید (پاپ‌آپ نشان داده می‌شود)، 1 = ثبت‌شده، 2 = بعداً در اپ، 3 = نادیده (در آمار حساب نمی‌شود)
data class Tx(val id: Long, val type: String, val amount: Long, val desc: String, val merchant: String,
              val time: Long, val status: Int, val cat: String, val bank: String)

data class Rule(val id: Long, val name: String, val bank: String, val type: String, val keyword: String,
                val before: String, val after: String, val rial: Boolean, val mBefore: String, val mAfter: String,
                val builtin: Boolean, val enabled: Boolean)

class Db(c: Context) : SQLiteOpenHelper(c, "tx.db", null, 4) {
    companion object {
        // فرمت‌های پیش‌فرض بانک بلو (قابل ویرایش، غیرفعال‌کردن و حذف)
        fun defaults() = listOf(
            Rule(0, "بلو — برداشت", "بلو", "withdraw", "برداشت پول", "", "ریال از حساب", true, "", "", true, true),
            Rule(0, "بلو — واریز", "بلو", "deposit", "واریز پول", "", "ریال به حساب", true, "", "", true, true),
            Rule(0, "بلو — خرید اینترنتی", "بلو", "purchase", "بلو", "مبلغ:", "ریال", true, "خرید", "", true, true)
        )
    }

    private fun seed(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE IF NOT EXISTS cat(name TEXT PRIMARY KEY)")
        listOf("خوراک", "حمل‌ونقل", "قبوض", "خرید", "سایر").forEach { d.execSQL("INSERT OR IGNORE INTO cat VALUES(?)", arrayOf(it)) }
    }
    private fun extra(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE IF NOT EXISTS rule(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,type TEXT,keyword TEXT,bef TEXT,aft TEXT,rial INTEGER,mb TEXT,ma TEXT,bank TEXT,builtin INTEGER DEFAULT 0,enabled INTEGER DEFAULT 1)")
        d.execSQL("CREATE TABLE IF NOT EXISTS unk(id INTEGER PRIMARY KEY AUTOINCREMENT,body TEXT)")
    }
    private fun rv(r: Rule) = ContentValues().apply {
        put("name", r.name); put("type", r.type); put("keyword", r.keyword); put("bef", r.before); put("aft", r.after)
        put("rial", if (r.rial) 1 else 0); put("mb", r.mBefore); put("ma", r.mAfter); put("bank", r.bank)
        put("builtin", if (r.builtin) 1 else 0); put("enabled", if (r.enabled) 1 else 0)
    }
    private fun seedRules(d: SQLiteDatabase) {
        d.rawQuery("SELECT COUNT(*) FROM rule WHERE builtin=1", null).use { c -> if (c.moveToFirst() && c.getInt(0) > 0) return }
        defaults().forEach { d.insert("rule", null, rv(it)) }
    }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT,amount INTEGER,descr TEXT,merchant TEXT,time INTEGER,done INTEGER,cat TEXT,bank TEXT)")
        seed(d); extra(d); seedRules(d)
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) { d.execSQL("ALTER TABLE tx ADD COLUMN cat TEXT"); d.execSQL("UPDATE tx SET amount=amount/10"); seed(d) }
        if (o < 4) d.execSQL("ALTER TABLE tx ADD COLUMN bank TEXT")
        if (o == 3) {
            d.execSQL("ALTER TABLE rule ADD COLUMN bank TEXT")
            d.execSQL("ALTER TABLE rule ADD COLUMN builtin INTEGER DEFAULT 0")
            d.execSQL("ALTER TABLE rule ADD COLUMN enabled INTEGER DEFAULT 1")
        }
        extra(d)
        seedRules(d)
    }

    private fun q(where: String?, order: String, limit: String? = null): List<Tx> =
        readableDatabase.query("tx", null, where, null, null, null, order, limit).use { c ->
            buildList { while (c.moveToNext()) add(Tx(c.getLong(0), c.getString(1) ?: "", c.getLong(2), c.getString(3) ?: "",
                c.getString(4) ?: "", c.getLong(5), c.getInt(6), c.getString(7) ?: "", c.getString(8) ?: "")) }
        }

    fun add(type: String, amount: Long, merchant: String, bank: String): Long =
        writableDatabase.insert("tx", null, ContentValues().apply {
            put("type", type); put("amount", amount); put("descr", ""); put("merchant", merchant)
            put("time", System.currentTimeMillis()); put("done", 0); put("cat", ""); put("bank", bank)
        })

    fun addManual(type: String, amount: Long, desc: String, cat: String, bank: String, time: Long) {
        writableDatabase.insert("tx", null, ContentValues().apply {
            put("type", type); put("amount", amount); put("descr", desc); put("merchant", "")
            put("time", time); put("done", 1); put("cat", cat); put("bank", bank)
        })
    }

    // پیامک تکراری (همان نوع و مبلغ در ۲۰ ثانیه اخیر)
    fun isDup(type: String, amount: Long): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM tx WHERE type=? AND amount=? AND time>? LIMIT 1",
        arrayOf(type, amount.toString(), (System.currentTimeMillis() - 20_000).toString())).use { it.moveToFirst() }

    // آخرین دسته‌ای که برای این پذیرنده انتخاب شده (برای پیشنهاد خودکار)
    fun lastCat(merchant: String): String = readableDatabase.rawQuery(
        "SELECT cat FROM tx WHERE done=1 AND merchant=? AND cat IS NOT NULL AND cat!='' ORDER BY time DESC LIMIT 1",
        arrayOf(merchant)).use { if (it.moveToFirst()) it.getString(0) ?: "" else "" }

    fun get(id: Long) = q("id=$id", "id").firstOrNull()
    fun pending() = q("done=0", "id ASC", "1").firstOrNull()
    fun open() = q("done IN (0,2)", "time DESC")
    fun ignored() = q("done=3", "time DESC")
    fun done() = q("done=1", "time DESC")
    fun expenses(from: Long, to: Long) = q("done=1 AND type!='deposit' AND time>=$from AND time<$to", "time ASC")

    private fun upd(id: Long, v: ContentValues) { writableDatabase.update("tx", v, "id=?", arrayOf(id.toString())) }
    fun finish(id: Long, amount: Long, desc: String, cat: String, type: String, bank: String, time: Long) =
        upd(id, ContentValues().apply {
            put("amount", amount); put("descr", desc); put("cat", cat); put("type", type); put("bank", bank); put("time", time); put("done", 1)
        })
    fun postpone(id: Long) = upd(id, ContentValues().apply { put("done", 2) })
    fun ignore(id: Long) = upd(id, ContentValues().apply { put("done", 3) })
    fun delete(id: Long) { writableDatabase.delete("tx", "id=?", arrayOf(id.toString())) }

    fun cats(): List<String> = readableDatabase.rawQuery("SELECT name FROM cat ORDER BY rowid", null).use { c ->
        buildList { while (c.moveToNext()) add(c.getString(0)) }
    }
    fun addCat(n: String) { writableDatabase.execSQL("INSERT OR IGNORE INTO cat VALUES(?)", arrayOf(n)) }
    fun delCat(n: String) { writableDatabase.execSQL("DELETE FROM cat WHERE name=?", arrayOf(n)) }

    // بانک‌های شناخته‌شده (از فرمت‌ها و تراکنش‌ها)
    fun banks(): List<String> = readableDatabase.rawQuery(
        "SELECT DISTINCT bank FROM (SELECT bank FROM rule UNION SELECT bank FROM tx) WHERE bank IS NOT NULL AND bank!='' ORDER BY bank", null).use { c ->
        buildList { while (c.moveToNext()) add(c.getString(0)) }
    }

    // فرمت‌های پیامک
    fun rules(): List<Rule> = readableDatabase.rawQuery(
        "SELECT id,name,type,keyword,bef,aft,rial,mb,ma,bank,builtin,enabled FROM rule ORDER BY id", null).use { c ->
        buildList {
            while (c.moveToNext()) add(Rule(c.getLong(0), c.getString(1) ?: "", c.getString(9) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "", c.getInt(6) == 1,
                c.getString(7) ?: "", c.getString(8) ?: "", c.getInt(10) == 1, c.getInt(11) == 1))
        }
    }
    fun addRule(r: Rule) { writableDatabase.insert("rule", null, rv(r)) }
    fun updateRule(r: Rule) { writableDatabase.update("rule", rv(r), "id=?", arrayOf(r.id.toString())) }
    fun setRuleEnabled(id: Long, on: Boolean) {
        writableDatabase.execSQL("UPDATE rule SET enabled=? WHERE id=?", arrayOf(if (on) 1 else 0, id))
    }
    fun delRule(id: Long) { writableDatabase.delete("rule", "id=?", arrayOf(id.toString())) }
    fun resetDefaults() {
        writableDatabase.execSQL("DELETE FROM rule WHERE builtin=1")
        seedRules(writableDatabase)
    }

    // پیامک‌های مالی که با هیچ فرمتی نخواندند (فقط روی همین گوشی، حداکثر ۱۲ تا)
    fun unknown(): List<Pair<Long, String>> = readableDatabase.rawQuery("SELECT id,body FROM unk ORDER BY id DESC", null).use { c ->
        buildList { while (c.moveToNext()) add(Pair(c.getLong(0), c.getString(1) ?: "")) }
    }
    fun addUnknown(body: String) {
        writableDatabase.execSQL("INSERT INTO unk(body) VALUES(?)", arrayOf(body))
        writableDatabase.execSQL("DELETE FROM unk WHERE id NOT IN (SELECT id FROM unk ORDER BY id DESC LIMIT 12)")
    }
    fun delUnknown(id: Long) { writableDatabase.delete("unk", "id=?", arrayOf(id.toString())) }
}
