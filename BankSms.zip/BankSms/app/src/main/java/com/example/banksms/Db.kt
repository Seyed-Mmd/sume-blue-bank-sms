package com.example.banksms

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// status: 0 = جدید (پاپ‌آپ نشان داده می‌شود)، 1 = ثبت‌شده، 2 = بعداً در اپ
data class Tx(val id: Long, val type: String, val amount: Long, val desc: String,
              val merchant: String, val time: Long, val status: Int, val cat: String)

data class Rule(val id: Long, val name: String, val type: String, val keyword: String,
                val before: String, val after: String, val rial: Boolean,
                val mBefore: String, val mAfter: String)

class Db(c: Context) : SQLiteOpenHelper(c, "tx.db", null, 3) {
    private fun seed(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE IF NOT EXISTS cat(name TEXT PRIMARY KEY)")
        listOf("خوراک", "حمل‌ونقل", "قبوض", "خرید", "سایر").forEach { d.execSQL("INSERT OR IGNORE INTO cat VALUES(?)", arrayOf(it)) }
    }
    private fun extra(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE IF NOT EXISTS rule(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,type TEXT,keyword TEXT,bef TEXT,aft TEXT,rial INTEGER,mb TEXT,ma TEXT)")
        d.execSQL("CREATE TABLE IF NOT EXISTS unk(id INTEGER PRIMARY KEY AUTOINCREMENT,body TEXT)")
    }
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT,amount INTEGER,descr TEXT,merchant TEXT,time INTEGER,done INTEGER,cat TEXT)")
        seed(d); extra(d)
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) { d.execSQL("ALTER TABLE tx ADD COLUMN cat TEXT"); d.execSQL("UPDATE tx SET amount=amount/10"); seed(d) }
        extra(d)
    }

    private fun q(where: String?, order: String, limit: String? = null): List<Tx> =
        readableDatabase.query("tx", null, where, null, null, null, order, limit).use { c ->
            buildList { while (c.moveToNext()) add(Tx(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3) ?: "",
                c.getString(4) ?: "", c.getLong(5), c.getInt(6), c.getString(7) ?: "")) }
        }

    fun add(type: String, amount: Long, merchant: String): Long =
        writableDatabase.insert("tx", null, ContentValues().apply {
            put("type", type); put("amount", amount); put("descr", ""); put("merchant", merchant)
            put("time", System.currentTimeMillis()); put("done", 0); put("cat", "")
        })

    fun addManual(type: String, amount: Long, desc: String, cat: String, time: Long) {
        writableDatabase.insert("tx", null, ContentValues().apply {
            put("type", type); put("amount", amount); put("descr", desc); put("merchant", "")
            put("time", time); put("done", 1); put("cat", cat)
        })
    }

    fun get(id: Long) = q("id=$id", "id").firstOrNull()
    fun pending() = q("done=0", "id ASC", "1").firstOrNull()
    fun open() = q("done!=1", "time DESC")
    fun done() = q("done=1", "time DESC")
    fun expenses(from: Long, to: Long) = q("done=1 AND type!='deposit' AND time>=$from AND time<$to", "time ASC")

    private fun upd(id: Long, v: ContentValues) { writableDatabase.update("tx", v, "id=?", arrayOf(id.toString())) }
    fun finish(id: Long, amount: Long, desc: String, cat: String, type: String, time: Long) =
        upd(id, ContentValues().apply { put("amount", amount); put("descr", desc); put("cat", cat); put("type", type); put("time", time); put("done", 1) })
    fun postpone(id: Long) = upd(id, ContentValues().apply { put("done", 2) })
    fun delete(id: Long) { writableDatabase.delete("tx", "id=?", arrayOf(id.toString())) }

    fun cats(): List<String> = readableDatabase.rawQuery("SELECT name FROM cat ORDER BY rowid", null).use { c ->
        buildList { while (c.moveToNext()) add(c.getString(0)) }
    }
    fun addCat(n: String) { writableDatabase.execSQL("INSERT OR IGNORE INTO cat VALUES(?)", arrayOf(n)) }
    fun delCat(n: String) { writableDatabase.execSQL("DELETE FROM cat WHERE name=?", arrayOf(n)) }

    // فرمت‌های پیامک کاربر
    fun rules(): List<Rule> = readableDatabase.rawQuery(
        "SELECT id,name,type,keyword,bef,aft,rial,mb,ma FROM rule ORDER BY id", null).use { c ->
        buildList { while (c.moveToNext()) add(Rule(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "",
            c.getString(4) ?: "", c.getString(5) ?: "", c.getInt(6) == 1, c.getString(7) ?: "", c.getString(8) ?: "")) }
    }
    fun addRule(r: Rule) {
        writableDatabase.insert("rule", null, ContentValues().apply {
            put("name", r.name); put("type", r.type); put("keyword", r.keyword); put("bef", r.before); put("aft", r.after)
            put("rial", if (r.rial) 1 else 0); put("mb", r.mBefore); put("ma", r.mAfter)
        })
    }
    fun delRule(id: Long) { writableDatabase.delete("rule", "id=?", arrayOf(id.toString())) }

    // پیامک‌های مالی که با هیچ فرمتی نخواندند (فقط روی همین گوشی، حداکثر ۱۲ تا)
    fun unknown(): List<Pair<Long, String>> = readableDatabase.rawQuery("SELECT id,body FROM unk ORDER BY id DESC", null).use { c ->
        buildList { while (c.moveToNext()) add(Pair(c.getLong(0), c.getString(1) ?: "")) }
    }
    fun addUnknown(body: String) {
        writableDatabase.execSQL("INSERT INTO unk(body) VALUES(?)", arrayOf(body))
        writableDatabase.execSQL("DELETE FROM unk WHERE id NOT IN (SELECT id FROM unk ORDER BY id DESC LIMIT 12)")
    }
    fun delUnknown(id: Long) { writableDatabase.delete("unk", "id=?", arrayOf(id.toString())) }
}
