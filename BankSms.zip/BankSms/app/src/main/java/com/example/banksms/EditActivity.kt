package com.example.banksms

// ویرایش / افزودن دستی از داخل اپ (همان صفحه پاپ‌آپ، ولی در همان تسک برنامه)
class EditActivity : PopupActivity()
