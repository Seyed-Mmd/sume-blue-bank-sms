package com.example.banksms

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.PowerManager

object Launcher {
    fun startService(c: Context) {
        try { c.startForegroundService(Intent(c, WatchService::class.java)) } catch (_: Exception) {}
    }
    // گوشی روشن و قفلش باز است؟
    fun usingPhone(c: Context): Boolean =
        c.getSystemService(PowerManager::class.java).isInteractive &&
            !c.getSystemService(KeyguardManager::class.java).isKeyguardLocked

    fun showPopupIfPending(c: Context) {
        if (Db(c).pending() == null) return
        try {
            c.startActivity(Intent(c, PopupActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        } catch (_: Exception) {}
    }
}
