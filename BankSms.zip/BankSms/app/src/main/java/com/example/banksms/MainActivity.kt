package com.example.banksms

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var tab = 0
    private var dFrom = ""
    private var dTo = ""
    private var filter = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val need = mutableListOf(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(need.toTypedArray(), 1)
        val r = Dates.thisMonth(); dFrom = r.first; dTo = r.second
        window.statusBarColor = C.bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    }

    override fun onResume() { super.onResume(); Launcher.startService(this); render() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun confirm(msg: String, ok: () -> Unit) = AlertDialog.Builder(this).setMessage(msg)
        .setPositiveButton("بله") { _, _ -> ok() }.setNegativeButton("خیر", null).show()
    private fun openTx(id: Long) = startActivity(Intent(this, PopupActivity::class.java).putExtra("id", id))

    // ───────────── قالب اصلی: محتوا + نوار پایین + دکمه شناور ─────────────
    private fun render() {
        val db = Db(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }
        when (tab) { 0 -> home(db, page); 1 -> txs(db, page); 2 -> report(db, page); else -> settings(db, page) }

        val root = FrameLayout(this).apply { setBackgroundColor(C.bg); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.put(ScrollView(this).apply { addView(page) }, 0, -1, 1f, 0, 0)
        col.put(navBar())
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        if (tab <= 1) {
            val fab = TextView(this).apply {
                text = "＋"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.primary) }
                elevation = dp(6).toFloat()
                setOnClickListener { startActivity(Intent(this@MainActivity, PopupActivity::class.java).putExtra("new", true)) }
            }
            val lp = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.START)
            lp.setMargins(dp(20), 0, dp(20), dp(84))
            root.addView(fab, lp)
        }
        setContentView(root)
    }

    private fun navBar(): View {
        val nav = LinearLayout(this).apply {
            background = shape(C.card, 0); elevation = dp(8).toFloat(); setPadding(0, dp(8), 0, dp(8))
        }
        val items = listOf("🏠" to "خانه", "📋" to "تراکنش‌ها", "📊" to "گزارش", "⚙️" to "تنظیمات")
        items.forEachIndexed { i, kv ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                addView(tv(kv.first, 20f))
                addView(tv(kv.second, 11f, if (i == tab) C.primary else C.muted, i == tab))
                setOnClickListener { tab = i; render() }
            }
            nav.put(item, 0, 0, 1f)
        }
        return nav
    }

    // ───────────── اجزای مشترک ─────────────
    private fun txRow(t: Tx, onClick: () -> Unit, onLong: (() -> Unit)? = null): View {
        val inc = t.type == "deposit"
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { onClick() }
        }
        if (onLong != null) row.setOnLongClickListener { onLong(); true }
        val icon = tv(if (inc) "＋" else "－", 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (inc) C.green else C.red) }
        }
        row.put(icon, 0, dp(40), 0f, 0, 40)
        val title = t.desc.ifEmpty { t.merchant }.ifEmpty { Parser.label(t.type) }
        val sub = (if (t.cat.isEmpty()) "" else t.cat + "  •  ") + Dates.fmtTime(t.time)
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.put(tv(title, 15f, C.text, true))
        mid.put(tv(sub, 12f, C.muted))
        row.put(mid, 0, 0, 1f, 12)
        row.put(tv(Parser.fmt(t.amount), 14f, if (inc) C.green else C.text, true), 0, -2, 0f, 8)
        return row
    }

    private fun bars(list: List<Tx>): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sums = list.filter { it.type != "deposit" }.groupBy { it.cat.ifEmpty { "بدون دسته" } }
            .mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }
        val max = sums.firstOrNull()?.value ?: 0L
        if (max == 0L) { box.put(tv("هنوز هزینه‌ای ثبت نشده", 13f, C.muted)); return box }
        sums.forEachIndexed { i, e ->
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            head.put(tv(e.key, 14f), 0, 0, 1f)
            head.put(tv(Parser.fmt(e.value), 13f, C.muted), 0, -2)
            box.put(head, if (i == 0) 0 else 14)
            val frac = (e.value.toFloat() / max).coerceIn(0.03f, 1f)
            val track = LinearLayout(this).apply { background = shape(C.chipBg, 4) }
            track.put(View(this).apply { background = shape(C.palette[i % C.palette.size], 4) }, 0, 0, frac, 0, 8)
            track.put(View(this), 0, 0, 1f - frac, 0, 8)
            box.put(track, 6)
        }
        return box
    }

    // ───────────── تب خانه ─────────────
    private fun home(db: Db, p: LinearLayout) {
        val range = Dates.monthRange()
        val month = db.done().filter { it.time >= range.first && it.time < range.second }
        val exp = month.filter { it.type != "deposit" }.sumOf { it.amount }
        val inc = month.filter { it.type == "deposit" }.sumOf { it.amount }
        val light = Color.parseColor("#DDE3FF")

        val h = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.primary, Color.parseColor("#7048E8")))
                .apply { cornerRadius = dp(24).toFloat() }
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        h.put(tv("هزینه این ماه", 13f, light))
        h.put(tv(Parser.fmt(exp), 30f, Color.WHITE, true), 4)
        val row = LinearLayout(this)
        fun stat(l: String, v: String): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(l, 12f, light)); addView(tv(v, 15f, Color.WHITE, true))
        }
        row.put(stat("درآمد این ماه", Parser.fmt(inc)), 0, 0, 1f)
        row.put(stat("تراز", Parser.fmt(inc - exp)), 0, 0, 1f)
        h.put(row, 16)
        p.put(h)

        if (!Settings.canDrawOverlays(this)) {
            val w = card()
            w.put(tv("⚠️ برای باز شدن خودکار پاپ‌آپ بعد از باز کردن قفل، اجازه «نمایش روی برنامه‌ها» را بده.", 13f))
            w.put(pill("دادن اجازه") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }, 8)
            p.put(w, 12)
        }

        val open = db.open()
        if (open.isNotEmpty()) {
            val c = card(12)
            c.put(tv("در انتظار ثبت (${open.size})", 16f, C.text, true))
            open.forEach { t -> c.put(txRow(t, { openTx(t.id) })) }
            p.put(c, 12)
        }

        val c2 = card()
        c2.put(tv("هزینه این ماه به تفکیک دسته", 16f, C.text, true))
        c2.put(bars(month), 12)
        p.put(c2, 12)

        val c3 = card(12)
        c3.put(tv("آخرین تراکنش‌ها", 16f, C.text, true))
        val last = db.done().take(5)
        if (last.isEmpty()) c3.put(tv("هنوز تراکنشی ثبت نشده. با دکمه ＋ یکی اضافه کن.", 13f, C.muted), 8)
        last.forEach { t -> c3.put(txRow(t, { openTx(t.id) })) }
        p.put(c3, 12)
    }

    // ───────────── تب تراکنش‌ها ─────────────
    private fun txs(db: Db, p: LinearLayout) {
        p.put(tv("تراکنش‌ها", 22f, C.text, true))
        val fl = Flow(this)
        fl.addView(chip("همه", filter == "") { filter = ""; render() })
        db.cats().forEach { n -> fl.addView(chip(n, filter == n) { filter = n; render() }) }
        p.put(fl, 8)
        val list = db.done().filter { filter == "" || it.cat == filter }
        val c = card(12)
        if (list.isEmpty()) c.put(tv("تراکنشی نیست", 13f, C.muted))
        list.forEach { t -> c.put(txRow(t, { openTx(t.id) }, { confirm("حذف شود؟") { db.delete(t.id); render() } })) }
        p.put(c, 12)
        val ign = db.ignored()
        if (ign.isNotEmpty()) {
            val g = card(12)
            g.put(tv("نادیده‌گرفته‌شده‌ها (${ign.size}) — در گزارش حساب نمی‌شوند", 14f, C.muted, true))
            ign.forEach { t -> g.put(txRow(t, { openTx(t.id) }, { confirm("برای همیشه حذف شود؟") { db.delete(t.id); render() } })) }
            p.put(g, 12)
        }
        p.put(tv("بزن = ویرایش (برای نادیده‌ها: ثبت دوباره)  •  نگه‌دار = حذف", 12f, C.muted), 8)
    }

    // ───────────── تب گزارش و خروجی ─────────────
    private fun report(db: Db, p: LinearLayout) {
        p.put(tv("گزارش و خروجی", 22f, C.text, true))
        val c = card()
        c.put(tv("بازه زمانی (تاریخ شمسی)", 13f, C.muted))
        val fl = Flow(this)
        listOf("این ماه" to Dates.thisMonth(), "ماه قبل" to Dates.prevMonth(), "۷ روز اخیر" to Dates.last7()).forEach { kv ->
            fl.addView(chip(kv.first, false) { dFrom = kv.second.first; dTo = kv.second.second; render() })
        }
        c.put(fl, 8)
        c.put(field("از (مثل 1405/07/01)", dFrom).apply { onText { dFrom = it } }, 8)
        c.put(field("تا (مثل 1405/07/30)", dTo).apply { onText { dTo = it } }, 8)
        c.put(pill("نمایش", C.chipBg, C.text) { render() }, 12)
        p.put(c, 12)

        val a = Dates.parseDay(dFrom); val b = Dates.parseDay(dTo)
        if (a == null || b == null) {
            p.put(tv("تاریخ‌ها را درست بنویس (مثل 1405/07/01)", 13f, C.red), 12)
            return
        }
        val list = db.expenses(a, b + 86_400_000L)
        val s = card()
        s.put(tv("جمع هزینه‌ها در این بازه", 13f, C.muted))
        s.put(tv(Parser.fmt(list.sumOf { it.amount }), 26f, C.text, true), 4)
        s.put(tv("${list.size} تراکنش", 12f, C.muted))
        s.put(bars(list), 14)
        p.put(s, 12)
        p.put(pill("📤 ارسال گزارش متنی") { exportText(list, a, b) }, 12)
    }

    private fun exportText(list: List<Tx>, a: Long, b: Long) {
        if (list.isEmpty()) { toast("در این بازه خرجی ثبت نشده"); return }
        val sb = StringBuilder("گزارش خرج‌ها\nاز ${Dates.fmtDay(a)} تا ${Dates.fmtDay(b)}\n\n")
        list.forEachIndexed { i, t ->
            val title = t.desc.ifEmpty { t.merchant }.ifEmpty { Parser.label(t.type) }
            val c = if (t.cat.isEmpty()) "" else " (${t.cat})"
            sb.append("${i + 1}. ${Dates.fmtDay(t.time)} — $title$c: ${Parser.fmt(t.amount)}\n")
        }
        sb.append("\nجمع کل: ${Parser.fmt(list.sumOf { it.amount })}")
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, sb.toString())
        }, null))
    }

    // ───────────── تب تنظیمات ─────────────
    private fun settings(db: Db, p: LinearLayout) {
        p.put(tv("تنظیمات", 22f, C.text, true))

        val c = card()
        c.put(tv("دسته‌بندی‌ها", 16f, C.text, true))
        c.put(tv("برای حذف روی دسته بزن", 12f, C.muted))
        val fl = Flow(this)
        db.cats().forEach { n ->
            fl.addView(chip("$n  ✕", false) { confirm("دسته «$n» حذف شود؟") { db.delCat(n); render() } })
        }
        c.put(fl, 8)
        val et = field("دسته جدید")
        c.put(et, 12)
        c.put(pill("افزودن دسته") {
            val s = et.text.toString().trim()
            if (s.isNotEmpty()) { db.addCat(s); render() }
        }, 8)
        p.put(c, 12)

        val r = card()
        r.put(tv("فرمت پیامک بانک‌ها", 16f, C.text, true))
        r.put(tv("فرمت بانک «بلو» (واریز، برداشت، خرید) از قبل فعال است. اگر بانک دیگری داری یا شکل پیامک فرق دارد، فرمت خودت را اضافه کن؛ آموزش هم داخل همان صفحه هست.", 13f, C.muted), 4)
        db.rules().forEach { ru ->
            val line = tv("•  ${ru.name}   ✕", 14f).apply {
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { confirm("این فرمت حذف شود؟") { db.delRule(ru.id); render() } }
            }
            r.put(line, 4)
        }
        r.put(pill("＋ افزودن فرمت (با آموزش)") {
            startActivity(Intent(this, RuleActivity::class.java))
        }, 8)
        p.put(r, 12)
    }
}
