package com.example.banksms

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.icu.util.Calendar
import android.icu.util.ULocale
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import java.util.Date

class MainActivity : Activity() {
    private val fa = ULocale("fa_IR@calendar=persian")
    private var from = ""
    private var to = ""
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val need = mutableListOf(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(need.toTypedArray(), 1)
        val df = SimpleDateFormat("yyyy/MM/dd", fa)
        val cal = Calendar.getInstance(fa)
        to = df.format(cal.time)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        from = df.format(cal.time)
    }
    override fun onResume() { super.onResume(); Launcher.startService(this); render() }

    private fun parseDay(s: String): Long? {
        val p = Parser.norm(s).trim().split('/', '-', '.').mapNotNull { it.trim().toIntOrNull() }
        if (p.size != 3) return null
        return Calendar.getInstance(fa).apply { clear(); set(p[0], p[1] - 1, p[2]) }.timeInMillis
    }

    private fun export() {
        val a = parseDay(from); val b = parseDay(to)
        if (a == null || b == null) { toast("تاریخ را مثل 1405/07/01 بنویس"); return }
        val list = Db(this).expenses(a, b + 86_400_000L)
        if (list.isEmpty()) { toast("در این بازه خرجی ثبت نشده"); return }
        val df = SimpleDateFormat("yyyy/MM/dd", fa)
        val sb = StringBuilder("گزارش خرج‌ها\nاز ${df.format(Date(a))} تا ${df.format(Date(b))}\n\n")
        list.forEachIndexed { i, t ->
            val title = t.desc.ifEmpty { t.merchant }.ifEmpty { Parser.label(t.type) }
            val c = if (t.cat.isEmpty()) "" else " (${t.cat})"
            sb.append("${i + 1}. ${df.format(Date(t.time))} — $title$c: ${Parser.fmt(t.amount)}\n")
        }
        sb.append("\nجمع کل: ${Parser.fmt(list.sumOf { it.amount })}")
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, sb.toString())
        }, null))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun confirm(msg: String, ok: () -> Unit) = AlertDialog.Builder(this).setMessage(msg)
        .setPositiveButton("بله") { _, _ -> ok() }.setNegativeButton("خیر", null).show()
    private fun openTx(id: Long) = startActivity(Intent(this, PopupActivity::class.java).putExtra("id", id))

    private fun render() {
        val db = Db(this)
        val list = db.done()
        val df = SimpleDateFormat("yyyy/MM/dd HH:mm", fa)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        fun tv(s: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
            text = s; textSize = size; if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(8))
        }.also { col.addView(it) }
        fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }.also { col.addView(it) }

        if (!Settings.canDrawOverlays(this)) {
            tv("برای باز شدن خودکار پاپ‌آپ بعد از باز کردن قفل، این اجازه لازم است:")
            btn("اجازه نمایش روی برنامه‌ها") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }

        val open = db.open()
        if (open.isNotEmpty()) {
            tv("در انتظار ثبت (${open.size}) — برای ثبت بزن", 17f, true)
            open.forEach { t -> tv("• ${Parser.label(t.type)} ${Parser.fmt(t.amount)} ${t.merchant}").setOnClickListener { openTx(t.id) } }
        }

        tv("گزارش", 22f, true)
        val dep = list.filter { it.type == "deposit" }.sumOf { it.amount }
        val out = list.filter { it.type != "deposit" }.sumOf { it.amount }
        tv("کل واریز: ${Parser.fmt(dep)}")
        tv("کل هزینه: ${Parser.fmt(out)}")
        tv("تراز: ${Parser.fmt(dep - out)}", 15f, true)
        tv("هزینه‌ها به تفکیک دسته", 17f, true)
        list.filter { it.type != "deposit" }.groupBy { it.cat.ifEmpty { "بدون دسته" } }
            .mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }
            .forEach { tv("• ${it.key}: ${Parser.fmt(it.value)}") }

        tv("خروجی متنی (برای ارسال)", 17f, true)
        tv("از تاریخ (مثل 1405/07/01)")
        col.addView(EditText(this).apply { setText(from); onText { from = it } })
        tv("تا تاریخ")
        col.addView(EditText(this).apply { setText(to); onText { to = it } })
        btn("ساخت و ارسال") { export() }

        tv("دسته‌بندی‌ها (برای حذف روی دسته بزن)", 17f, true)
        db.cats().forEach { c -> tv("✕  $c").setOnClickListener { confirm("دسته «$c» حذف شود؟") { db.delCat(c); render() } } }
        val et = EditText(this).apply { hint = "دسته جدید" }
        col.addView(et)
        btn("افزودن دسته") { val s = et.text.toString().trim(); if (s.isNotEmpty()) { db.addCat(s); render() } }

        tv("همه تراکنش‌ها (بزن = ویرایش، نگه‌دار = حذف)", 17f, true)
        list.forEach { t ->
            val tx = tv("${if (t.type == "deposit") "＋" else "－"} ${Parser.fmt(t.amount)}  |  " +
                "${t.desc.ifEmpty { Parser.label(t.type) }}${if (t.cat.isEmpty()) "" else " (${t.cat})"}\n${df.format(Date(t.time))}")
            tx.setOnClickListener { openTx(t.id) }
            tx.setOnLongClickListener { confirm("حذف شود؟") { db.delete(t.id); render() }; true }
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun EditText.onText(f: (String) -> Unit) = addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { f(s.toString()) }
    })
}
