package com.example.banksms

import java.util.Locale

object Parser {
    fun norm(s: String) = s.map {
        when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); else -> it }
    }.joinToString("")

    fun label(type: String) = when (type) { "withdraw" -> "برداشت"; "deposit" -> "واریز"; "purchase" -> "خرید اینترنتی"; else -> "تراکنش" }
    fun fmt(n: Long) = String.format(Locale.US, "%,d", n) + " تومان"

    // خروجی: (نوع, مبلغ به تومان, نام پذیرنده) — اول فرمت‌های خود کاربر، بعد فرمت پیش‌فرض بلو
    fun parse(raw: String, rules: List<Rule>): Triple<String, Long, String>? {
        val t = norm(raw)
        for (r in rules) matchRule(t, r)?.let { return it }
        return builtin(t)
    }

    private fun builtin(t: String): Triple<String, Long, String>? {
        if (!t.contains("بلو")) return null
        val type = when {
            t.contains("برداشت") -> "withdraw"
            t.contains("واریز") -> "deposit"
            t.contains("خرید") -> "purchase"
            else -> return null
        }
        val amt = Regex("""مبلغ:\s*([\d,]+)""").find(t)?.groupValues?.get(1)
            ?: Regex("""([\d,]+)\s*ریال""").find(t)?.groupValues?.get(1) ?: return null
        val rial = amt.replace(",", "").toLongOrNull() ?: return null
        val merchant = if (type == "purchase")
            Regex("""خرید\s*\n\s*(.+)""").find(t)?.groupValues?.get(1)?.trim() ?: "" else ""
        return Triple(type, rial / 10, merchant)
    }

    // متنِ اطراف را به الگو تبدیل می‌کند (فاصله/خط‌جدید انعطاف‌پذیر)
    private fun ctx(s: String): String =
        if (s.isBlank()) "" else norm(s).trim().split(Regex("\\s+")).joinToString("\\s*") { Regex.escape(it) }

    // t باید قبلاً norm شده باشد
    fun matchRule(t: String, r: Rule): Triple<String, Long, String>? {
        return try {
            if (r.keyword.isNotBlank() && !t.contains(norm(r.keyword).trim())) return null
            val m = Regex(ctx(r.before) + "\\s*([\\d,]+)\\s*" + ctx(r.after)).find(t) ?: return null
            val n = m.groupValues[1].replace(",", "").toLongOrNull() ?: return null
            var merchant = ""
            if (r.mBefore.isNotEmpty() || r.mAfter.isNotEmpty()) {
                val tail = if (r.mAfter.isEmpty()) "(?:\\n|$)" else ctx(r.mAfter)
                merchant = Regex(ctx(r.mBefore) + "\\s*([^\\n]+?)\\s*" + tail).find(t)?.groupValues?.get(1)?.trim() ?: ""
            }
            Triple(r.type, if (r.rial) n / 10 else n, merchant)
        } catch (e: Exception) { null }
    }

    // از روی یک پیامک نمونه، فرمت می‌سازد
    fun learn(sample: String, amountText: String, merchantText: String, keyword: String, type: String, rial: Boolean): Rule? {
        val s = norm(sample)
        val a = norm(amountText).trim()
        val i = s.indexOf(a)
        if (a.isEmpty() || i < 0) return null
        val before = s.substring(maxOf(0, i - 12), i).trim()
        val after = s.substring(i + a.length, minOf(s.length, i + a.length + 8)).trim()
        var mb = ""; var ma = ""
        val m = norm(merchantText).trim()
        if (m.isNotEmpty()) {
            val j = s.indexOf(m)
            if (j >= 0) {
                mb = s.substring(maxOf(0, j - 10), j).trim()
                ma = s.substring(j + m.length).takeWhile { it != '\n' }.trim().take(8)
            }
        }
        return Rule(0, label(type) + " — " + keyword, type, keyword, before, after, rial, mb, ma)
    }

    // آیا پیامک شبیه پیامک مالی است؟ (برای فهرست «شناخته‌نشده‌ها»)
    fun looksFinancial(raw: String): Boolean {
        val t = norm(raw)
        return Regex("""\d[\d,]{2,}""").containsMatchIn(t) &&
            listOf("ریال", "تومان", "مبلغ", "برداشت", "واریز", "خرید", "موجودی", "حساب").any { t.contains(it) }
    }
}
