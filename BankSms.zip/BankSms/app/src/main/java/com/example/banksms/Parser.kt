package com.example.banksms

import java.util.Locale

data class Parsed(val type: String, val amount: Long, val merchant: String, val bank: String)

object Parser {
    // یکسان‌سازی متن: ارقام فارسی/عربی، «ي»/«ك» عربی، حذف کاراکترهای نامرئی (جهت‌نمای متن، نیم‌فاصله)
    fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            when (ch) {
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                'ي', 'ى' -> sb.append('ی')
                'ك' -> sb.append('ک')
                '٬', '،' -> sb.append(',')
                '−', '–', '—', '‒' -> sb.append('-')
                '\u200C', '\u200B', '\u200D', '\u200E', '\u200F', '\uFEFF', '\u00AD',
                in '\u202A'..'\u202E', in '\u2066'..'\u2069' -> {}
                '\u00A0' -> sb.append(' ')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun label(type: String) = when (type) { "withdraw" -> "برداشت"; "deposit" -> "واریز"; "purchase" -> "خرید اینترنتی"; else -> "تراکنش" }
    fun fmt(n: Long) = String.format(Locale.US, "%,d", n) + " تومان"
    fun ruleName(bank: String, type: String) = bank.ifEmpty { "بدون نام" } + " — " + label(type)

    // اولین فرمت فعالی که پیام را بخواند
    fun parse(raw: String, rules: List<Rule>): Parsed? {
        val t = norm(raw)
        for (r in rules) {
            if (!r.enabled) continue
            matchRule(t, r)?.let { return it }
        }
        return null
    }

    // متنِ اطراف را به الگو تبدیل می‌کند (فاصله/خط‌جدید انعطاف‌پذیر).
    // عددها (شماره کارت، حساب، پیگیری) در هر پیامک فرق می‌کنند؛ پس هر دنباله عدد = «هر عددی»
    private fun ctx(s: String): String =
        if (s.isBlank()) "" else norm(s).trim().split(Regex("\\s+")).joinToString("\\s*") { token ->
            Regex("\\d+|\\D+").findAll(token).joinToString("") { m ->
                if (m.value[0].isDigit()) "\\d+" else Regex.escape(m.value)
            }
        }

    // t باید قبلاً norm شده باشد
    fun matchRule(t: String, r: Rule): Parsed? {
        return try {
            if (r.keyword.isNotBlank() && !t.contains(norm(r.keyword).trim())) return null
            val m = Regex(ctx(r.before) + "\\s*([\\d,]+)\\s*" + ctx(r.after)).find(t) ?: return null
            val n = m.groupValues[1].replace(",", "").toLongOrNull() ?: return null
            var merchant = ""
            if (r.mBefore.isNotEmpty() || r.mAfter.isNotEmpty()) {
                val tail = if (r.mAfter.isEmpty()) "(?:\\n|$)" else ctx(r.mAfter)
                merchant = Regex(ctx(r.mBefore) + "\\s*([^\\n]+?)\\s*" + tail).find(t)?.groupValues?.get(1)?.trim() ?: ""
            }
            Parsed(r.type, if (r.rial) n / 10 else n, merchant, r.bank)
        } catch (e: Exception) { null }
    }

    // از روی یک پیامک نمونه، فرمت می‌سازد
    fun learn(sample: String, amountText: String, merchantText: String, keyword: String,
              type: String, rial: Boolean, bank: String): Rule? {
        val s = norm(sample)
        // علامت منفی/مثبت کنار مبلغ (مثل -3,730,990) جزو مبلغ حساب نمی‌شود؛ جزو «متن قبل» می‌ماند
        val a = norm(amountText).trim().trimStart('-', '+').trim()
        val i = s.indexOf(a)
        if (a.isEmpty() || i < 0) return null
        // چند کلمه (کامل) قبل و بعد از مبلغ
        val beforeTokens = s.substring(0, i).trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val afterTokens = s.substring(i + a.length).trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val before = beforeTokens.takeLast(3).joinToString(" ")
        // حداکثر ۲ کلمه بعد از مبلغ، تا اولین کلمه‌ای که عدد دارد (عددها هر بار فرق می‌کنند)
        val after = afterTokens.takeWhile { w -> w.none { it.isDigit() } }.take(2).joinToString(" ")
        var mb = ""; var ma = ""
        val m = norm(merchantText).trim()
        if (m.isNotEmpty()) {
            val j = s.indexOf(m)
            if (j >= 0) {
                mb = s.substring(0, j).trim().split(Regex("\\s+")).takeLast(2).joinToString(" ")
                ma = s.substring(j + m.length).takeWhile { it != '\n' }.trim().take(8)
            }
        }
        return Rule(0, ruleName(bank, type), bank, type, keyword, before, after, rial, mb, ma, false, true)
    }

    // آیا پیامک شبیه پیامک مالی است؟ (برای فهرست «شناخته‌نشده‌ها»)
    fun looksFinancial(raw: String): Boolean {
        val t = norm(raw)
        return Regex("""\d[\d,]{2,}""").containsMatchIn(t) &&
            listOf("ریال", "تومان", "مبلغ", "برداشت", "واریز", "خرید", "موجودی", "حساب").any { t.contains(it) }
    }
}
