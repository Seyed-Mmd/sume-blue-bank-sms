package com.example.banksms

import java.util.Locale

object Parser {
    fun norm(s: String) = s.map {
        when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); else -> it }
    }.joinToString("")

    // خروجی: (نوع, مبلغ به تومان, نام پذیرنده)
    fun parse(raw: String): Triple<String, Long, String>? {
        val t = norm(raw)
        if (!t.contains("بلو")) return null
        val type = when {
            t.contains("برداشت") -> "withdraw"
            t.contains("واریز") -> "deposit"
            t.contains("خرید") -> "purchase"
            else -> return null
        }
        val amt = Regex("""مبلغ:\s*([\d,]+)""").find(t)?.groupValues?.get(1)
            ?: Regex("""([\d,]+)\s*ریال""").find(t)?.groupValues?.get(1) ?: return null
        val rial = amt.replace(",", "").toLongOrNull() ?: return null
        val merchant = if (type == "purchase")
            Regex("""خرید\s*\n\s*(.+)""").find(t)?.groupValues?.get(1)?.trim() ?: "" else ""
        return Triple(type, rial / 10, merchant)
    }

    fun label(type: String) = when (type) { "withdraw" -> "برداشت"; "deposit" -> "واریز"; else -> "خرید اینترنتی" }
    fun fmt(n: Long) = String.format(Locale.US, "%,d", n) + " تومان"
}
