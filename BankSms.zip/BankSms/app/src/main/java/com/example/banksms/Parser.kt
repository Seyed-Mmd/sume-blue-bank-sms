package com.example.banksms

import java.util.Locale

data class Parsed(val type: String, val amount: Long, val merchant: String, val bank: String)

object Parser {
    fun norm(s: String) = s.map {
        when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); else -> it }
    }.joinToString("")

    fun label(type: String) = when (type) { "withdraw" -> "برداشت"; "deposit" -> "واریز"; "purchase" -> "خرید اینترنتی"; else -> "تراکنش" }
    fun fmt(n: Long) = String.format(Locale.US, "%,d", n) + " تومان"
    fun ruleName(bank: String, type: String) = bank.ifEmpty { "بدون نام" } + " — " + label(type)

    // اولین فرمت فعالی که پیام را بخواند
    fun parse(raw: String, rules: List<Rule>): Parsed? {
        val t = norm(raw)
        for (r in rules) {
            if (!r.enabled) continue
            matchRule(t, r)?.let { return it }
        }
        return null
    }

    // متنِ اطراف را به الگو تبدیل می‌کند (فاصله/خط‌جدید انعطاف‌پذیر)
    private fun ctx(s: String): String =
        if (s.isBlank()) "" else norm(s).trim().split(Regex("\\s+")).joinToString("\\s*") { Regex.escape(it) }

    // t باید قبلاً norm شده باشد
    fun matchRule(t: String, r: Rule): Parsed? {
        return try {
            if (r.keyword.isNotBlank() && !t.contains(norm(r.keyword).trim())) return null
            val m = Regex(ctx(r.before) + "\\s*([\\d,]+)\\s*" + ctx(r.after)).find(t) ?: return null
            val n = m.groupValues[1].replace(",", "").toLongOrNull() ?: return null
            var merchant = ""
            if (r.mBefore.isNotEmpty() || r.mAfter.isNotEmpty()) {
                val tail = if (r.mAfter.isEmpty()) "(?:\\n|$)" else ctx(r.mAfter)
                merchant = Regex(ctx(r.mBefore) + "\\s*([^\\n]+?)\\s*" + tail).find(t)?.groupValues?.get(1)?.trim() ?: ""
            }
            Parsed(r.type, if (r.rial) n / 10 else n, merchant, r.bank)
        } catch (e: Exception) { null }
    }

    // از روی یک پیامک نمونه، فرمت می‌سازد
    fun learn(sample: String, amountText: String, merchantText: String, keyword: String,
              type: String, rial: Boolean, bank: String): Rule? {
        val s = norm(sample)
        val a = norm(amountText).trim()
        val i = s.indexOf(a)
        if (a.isEmpty() || i < 0) return null
        val before = s.substring(maxOf(0, i - 12), i).trim()
        val after = s.substring(i + a.length, minOf(s.length, i + a.length + 8)).trim()
        var mb = ""; var ma = ""
        val m = norm(merchantText).trim()
        if (m.isNotEmpty()) {
            val j = s.indexOf(m)
            if (j >= 0) {
                mb = s.substring(maxOf(0, j - 10), j).trim()
                ma = s.substring(j + m.length).takeWhile { it != '\n' }.trim().take(8)
            }
        }
        return Rule(0, ruleName(bank, type), bank, type, keyword, before, after, rial, mb, ma, false, true)
    }

    // آیا پیامک شبیه پیامک مالی است؟ (برای فهرست «شناخته‌نشده‌ها»)
    fun looksFinancial(raw: String): Boolean {
        val t = norm(raw)
        return Regex("""\d[\d,]{2,}""").containsMatchIn(t) &&
            listOf("ریال", "تومان", "مبلغ", "برداشت", "واریز", "خرید", "موجودی", "حساب").any { t.contains(it) }
    }
}
