package com.example.banksms

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*

class PopupActivity : Activity() {
    private lateinit var db: Db
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) { super.onCreate(b); db = Db(this); render() }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); if (i.hasExtra("id")) render() }

    private fun render() {
        val id = intent.getLongExtra("id", -1L)
        val fromApp = id != -1L
        val t = (if (fromApp) db.get(id) else db.pending()) ?: run { finish(); return }
        fun after() { if (fromApp) finish() else render() }

        val names = listOf("بدون دسته") + db.cats().let { if (t.cat.isNotEmpty() && t.cat !in it) it + t.cat else it }
        val title = TextView(this).apply {
            text = Parser.label(t.type) + if (t.merchant.isNotEmpty()) " — ${t.merchant}" else ""
            textSize = 18f
        }
        val amount = EditText(this).apply { setText(t.amount.toString()); inputType = InputType.TYPE_CLASS_NUMBER; hint = "مبلغ (تومان)" }
        val desc = EditText(this).apply { hint = "این چی بود؟"; setText(t.desc.ifEmpty { t.merchant }); setSelection(text.length) }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@PopupActivity, android.R.layout.simple_spinner_dropdown_item, names)
            setSelection(maxOf(0, names.indexOf(t.cat)))
        }
        fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }
        val row = LinearLayout(this).apply {
            val p = { LinearLayout.LayoutParams(0, -2, 1f) }
            addView(btn("ثبت") {
                val a = Parser.norm(amount.text.toString()).toLongOrNull() ?: t.amount
                val cat = if (sp.selectedItemPosition == 0) "" else names[sp.selectedItemPosition]
                db.finish(t.id, a, desc.text.toString().trim(), cat); after()
            }, p())
            addView(btn("بعداً در اپ") { db.postpone(t.id); if (fromApp) finish() else render() }, p())
            addView(btn("حذف") { db.delete(t.id); after() }, p())
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(20), dp(20), dp(12))
            addView(title); addView(amount); addView(desc)
            addView(TextView(context).apply { text = "دسته:" }); addView(sp); addView(row)
        })
    }
}
