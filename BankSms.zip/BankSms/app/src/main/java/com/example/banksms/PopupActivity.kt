package com.example.banksms

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

// سه حالت: پاپ‌آپ خودکار (تراکنش جدید) / ویرایش (id) / افزودن دستی (new)
class PopupActivity : Activity() {
    private lateinit var db: Db

    override fun onCreate(b: Bundle?) { super.onCreate(b); db = Db(this); render() }
    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i); setIntent(i)
        if (i.hasExtra("id") || i.hasExtra("new")) render()
    }

    private fun render() {
        val id = intent.getLongExtra("id", -1L)
        val manual = intent.getBooleanExtra("new", false)
        val inApp = manual || id != -1L
        val t: Tx? = if (manual) null else if (inApp) db.get(id) else db.pending()
        if (!manual && t == null) { finish(); return }

        var type = t?.type ?: "withdraw"
        var cat = t?.cat ?: ""
        val now = t?.time ?: System.currentTimeMillis()
        fun after() { if (inApp) finish() else render() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(20), dp(20), dp(16))
        }
        val title = when {
            manual -> "افزودن دستی"
            inApp -> "ویرایش تراکنش"
            else -> "تراکنش جدید — " + Parser.label(t!!.type) + (if (t.merchant.isNotEmpty()) " (${t.merchant})" else "")
        }
        root.put(tv(title, 18f, C.text, true))

        if (inApp) {
            val typeRow = LinearLayout(this)
            fun fillType() {
                typeRow.removeAllViews()
                listOf("withdraw" to "هزینه", "deposit" to "درآمد").forEachIndexed { i, kv ->
                    typeRow.put(chip(kv.second, type == kv.first) { type = kv.first; fillType() }, 0, -2, 0f, if (i == 0) 0 else 8)
                }
            }
            fillType()
            root.put(typeRow, 12)
        }

        root.put(tv("مبلغ (تومان)", 12f, C.muted), 12)
        val amount = field("مثلاً 150000", t?.amount?.toString() ?: "", true).apply {
            textSize = 24f; setTypeface(typeface, Typeface.BOLD)
        }
        root.put(amount, 4)

        root.put(tv("این چی بود؟", 12f, C.muted), 12)
        val desc = field("مثلاً شام، بنزین، قبض برق", t?.let { x -> x.desc.ifEmpty { x.merchant } } ?: "")
        root.put(desc, 4)

        root.put(tv("دسته", 12f, C.muted), 12)
        val names = db.cats().let { if (cat.isNotEmpty() && cat !in it) it + cat else it }
        val flow = Flow(this)
        fun fillCats() {
            flow.removeAllViews()
            flow.addView(chip("بدون دسته", cat == "") { cat = ""; fillCats() })
            names.forEach { n -> flow.addView(chip(n, cat == n) { cat = n; fillCats() }) }
        }
        fillCats()
        root.put(flow, 4)

        val dateF = if (inApp) field("تاریخ شمسی (مثل 1405/07/13)", Dates.fmtDay(now)) else null
        if (dateF != null) { root.put(tv("تاریخ", 12f, C.muted), 12); root.put(dateF, 4) }

        fun timeOf(): Long {
            if (dateF == null) return now
            val s = Parser.norm(dateF.text.toString()).trim()
            if (s == Parser.norm(Dates.fmtDay(now))) return now
            return Dates.parseDay(s)?.plus(43_200_000L) ?: now
        }

        root.put(pill("ثبت") {
            val a = Parser.norm(amount.text.toString()).replace(",", "").toLongOrNull()
            if (a == null || a <= 0) {
                Toast.makeText(this, "مبلغ را درست بنویس", Toast.LENGTH_SHORT).show(); return@pill
            }
            val d = desc.text.toString().trim()
            if (manual) db.addManual(type, a, d, cat, timeOf()) else db.finish(t!!.id, a, d, cat, type, timeOf())
            after()
        }, 20)

        val row = LinearLayout(this)
        if (manual) {
            row.put(pill("انصراف", C.chipBg, C.text) { finish() }, 0, 0, 1f)
        } else if (inApp) {
            row.put(pill("حذف", C.redBg, C.red) { db.delete(t!!.id); finish() }, 0, 0, 1f)
            row.put(pill("انصراف", C.chipBg, C.text) { finish() }, 0, 0, 1f, 8)
        } else {
            row.put(pill("بعداً در اپ", C.chipBg, C.text) { db.postpone(t!!.id); after() }, 0, 0, 1f)
            row.put(pill("حذف", C.redBg, C.red) { db.delete(t!!.id); after() }, 0, 0, 1f, 8)
        }
        root.put(row, 8)

        setContentView(ScrollView(this).apply { addView(root) })
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        window.setBackgroundDrawable(shape(Color.WHITE, 24))
    }
}
