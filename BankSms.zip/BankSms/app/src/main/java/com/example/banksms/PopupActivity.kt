package com.example.banksms

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView

// سه حالت: پاپ‌آپ خودکار (تراکنش جدید) / ویرایش (id) / افزودن دستی (new)
// پاپ‌آپ خودکار در تسک جدا و شفاف باز می‌شود تا روی برنامه‌ای که باز است بیاید و خود اپ باز نشود.
open class PopupActivity : Activity() {
    private lateinit var db: Db

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        C.load(this)
        setFinishOnTouchOutside(false)   // لمس بیرون از پاپ‌آپ، آن را نمی‌بندد
        db = Db(this)
        render()
    }
    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i); setIntent(i)
        if (i.hasExtra("id") || i.hasExtra("new")) render()
    }

    private fun render() {
        val id = intent.getLongExtra("id", -1L)
        val manual = intent.getBooleanExtra("new", false)
        val inApp = manual || id != -1L
        val t: Tx? = if (manual) null else if (inApp) db.get(id) else db.pending()
        if (!manual && t == null) { finish(); return }

        var type = t?.type ?: "withdraw"
        var cat = t?.cat ?: ""
        var bank = t?.bank ?: ""
        val now = t?.time ?: System.currentTimeMillis()
        // پیشنهاد خودکار دسته بر اساس آخرین انتخاب برای همین پذیرنده
        if (!inApp && cat.isEmpty() && t != null && t.merchant.isNotEmpty()) cat = db.lastCat(t.merchant)
        fun after() { if (inApp) finish() else render() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(16), dp(18), dp(12))
        }
        root.put(tv(if (manual) "افزودن دستی" else if (inApp) "ویرایش تراکنش" else "تراکنش جدید", 17f, C.text, true))
        if (!inApp && t != null) {
            // نشان می‌دهد پول از کدام بانک کم شده / به کدام بانک آمده
            val what = when (t.type) { "deposit" -> "واریز به"; "withdraw" -> "برداشت از"; else -> "خرید اینترنتی از" }
            val sub = (if (t.bank.isNotEmpty()) "$what بانک ${t.bank}" else Parser.label(t.type)) +
                (if (t.merchant.isNotEmpty()) "  •  ${t.merchant}" else "")
            root.put(tv(sub, 13f, C.muted), 2)
        }

        if (inApp) {
            val typeRow = LinearLayout(this)
            fun fillType() {
                typeRow.removeAllViews()
                listOf("withdraw" to "هزینه", "deposit" to "درآمد").forEachIndexed { i, kv ->
                    typeRow.put(chip(kv.second, type == kv.first) { type = kv.first; fillType() }, 0, -2, 0f, if (i == 0) 0 else 8)
                }
            }
            fillType()
            root.put(typeRow, 10)
        }

        root.put(tv("مبلغ (تومان)", 12f, C.muted), 10)
        val amount = field("مثلاً 150000", t?.amount?.toString() ?: "", true).apply {
            textSize = 22f; typeface = vazir(true)
        }
        root.put(amount, 4)

        root.put(tv("این چی بود؟", 12f, C.muted), 10)
        val desc = field("مثلاً شام، بنزین، قبض برق", t?.let { x -> x.desc.ifEmpty { x.merchant } } ?: "")
        root.put(desc, 4)

        root.put(tv("دسته", 12f, C.muted), 10)
        val names = db.cats().let { if (cat.isNotEmpty() && cat !in it) it + cat else it }
        val flow = Flow(this)
        fun fillCats() {
            flow.removeAllViews()
            flow.addView(chip("بدون دسته", cat == "") { cat = ""; fillCats() })
            names.forEach { n -> flow.addView(chip(n, cat == n) { cat = n; fillCats() }) }
        }
        fillCats()
        root.put(flow, 4)

        if (inApp) {
            root.put(tv("بانک", 12f, C.muted), 10)
            val banks = db.banks().let { if (bank.isNotEmpty() && bank !in it) it + bank else it }
            val bFlow = Flow(this)
            fun fillBanks() {
                bFlow.removeAllViews()
                bFlow.addView(chip("نقدی / نامشخص", bank == "") { bank = ""; fillBanks() })
                banks.forEach { n -> bFlow.addView(chip(n, bank == n) { bank = n; fillBanks() }) }
            }
            fillBanks()
            root.put(bFlow, 4)
        }

        val dateF = if (inApp) field("تاریخ شمسی (مثل 1405/07/13)", Dates.fmtDay(now)) else null
        if (dateF != null) { root.put(tv("تاریخ", 12f, C.muted), 10); root.put(dateF, 4) }

        fun timeOf(): Long {
            if (dateF == null) return now
            val s = Parser.norm(dateF.text.toString()).trim()
            if (s == Parser.norm(Dates.fmtDay(now))) return now
            return Dates.parseDay(s)?.plus(43_200_000L) ?: now
        }

        root.put(pill("ثبت") {
            val a = Parser.norm(amount.text.toString()).replace(",", "").toLongOrNull()
            if (a == null || a <= 0) { toast("مبلغ را درست بنویس"); return@pill }
            val d = desc.text.toString().trim()
            if (manual) db.addManual(type, a, d, cat, bank, timeOf()) else db.finish(t!!.id, a, d, cat, type, bank, timeOf())
            after()
        }, 16)

        val row = LinearLayout(this)
        if (manual) {
            row.put(pill("انصراف", C.chipBg, C.text) { finish() }, 0, 0, 1f)
        } else if (inApp) {
            row.put(pill("حذف", C.redBg, C.red) { db.delete(t!!.id); finish() }, 0, 0, 1f)
            row.put(pill("انصراف", C.chipBg, C.text) { finish() }, 0, 0, 1f, 8)
        } else {
            row.put(pill("بعداً در اپ", C.chipBg, C.text) { db.postpone(t!!.id); after() }, 0, 0, 1f)
            row.put(pill("نادیده بگیر", C.redBg, C.red) { db.ignore(t!!.id); after() }, 0, 0, 1f, 8)
        }
        root.put(row, 8)

        setContentView(ScrollView(this).apply { addView(root) })
        // پاپ‌آپ کوچک‌تر از عرض صفحه
        val dm = resources.displayMetrics
        window.setLayout(minOf((dm.widthPixels * 0.88f).toInt(), dp(400)), ViewGroup.LayoutParams.WRAP_CONTENT)
        window.setBackgroundDrawable(shape(C.card, 24))
    }
}
