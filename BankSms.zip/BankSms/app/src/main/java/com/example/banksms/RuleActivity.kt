package com.example.banksms

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

private val TUTORIAL = listOf(
    "فرمت بانک «بلو» (واریز، برداشت، خرید) از قبل فعال است. اگر بانک دیگری داری یا شکل پیامک فرق دارد، اینجا فرمت خودت را به برنامه یاد بده:",
    "",
    "۱) متن کامل یک پیامک واقعی بانک را در کادر «متن نمونه» بچسبان. اگر پیامکی ارسال شده و برنامه نخوانده، همین بالا در لیست «شناخته نشدند» هست؛ رویش بزن تا خودکار پر شود.",
    "۲) «نوع پیام» را انتخاب کن: برداشت، واریز یا خرید.",
    "۳) مبلغ را دقیقاً همان‌طور که در پیام نوشته شده بنویس؛ مثلاً 500,000 (نه مبلغ موجودی!).",
    "۴) واحد مبلغ را در پیام مشخص کن: ریال یا تومان. برنامه همیشه به تومان ذخیره می‌کند.",
    "۵) «عبارت شناسایی» یک کلمه یا جمله ثابت است که در همه پیام‌های همین نوع هست؛ مثلاً «برداشت پول» یا «به حساب نشست». اگر خالی بگذاری، خود نوع پیام (مثلاً «برداشت») استفاده می‌شود.",
    "۶) فقط برای خرید: نام فروشگاه را هم همان‌طور که در پیام هست بنویس (اختیاری).",
    "۷) دکمه «تست» را بزن. اگر مبلغ درست درآمد، «ذخیره» کن.",
    "",
    "نکته: برای هر نوع پیام یک فرمت جدا بساز؛ یکی برای واریز، یکی برای برداشت. پیامک‌هایی که هنوز نخوانده، فقط روی همین گوشی نگه داشته می‌شوند (حداکثر ۱۲ تا)."
).joinToString("\n")

class RuleActivity : Activity() {
    private lateinit var db: Db
    private var type = "withdraw"
    private var rial = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this)
        window.statusBarColor = C.bg
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        p.put(tv("افزودن فرمت پیامک", 22f, C.text, true))

        val tut = card()
        tut.put(tv("آموزش", 16f, C.text, true))
        tut.put(tv(TUTORIAL, 13f, C.muted).apply { setLineSpacing(0f, 1.3f) }, 8)
        p.put(tut, 12)

        val sample = field("متن کامل یک پیامک نمونه را اینجا بچسبان").apply {
            minLines = 4; gravity = Gravity.TOP or Gravity.START
        }

        val unk = db.unknown()
        if (unk.isNotEmpty()) {
            val u = card()
            u.put(tv("پیامک‌های اخیر که شناخته نشدند — یکی را بزن", 14f, C.text, true))
            val fl = Flow(this)
            unk.forEach { pr ->
                val body = pr.second
                fl.addView(chip(body.replace("\n", " ").take(26) + "…", false) { sample.setText(body) })
            }
            u.put(fl, 8)
            p.put(u, 12)
        }

        val f = card()
        f.put(tv("متن نمونه پیامک", 13f, C.muted))
        f.put(sample, 4)

        f.put(tv("نوع پیام", 13f, C.muted), 12)
        val typeRow = Flow(this)
        fun fillType() {
            typeRow.removeAllViews()
            listOf("withdraw" to "برداشت", "deposit" to "واریز", "purchase" to "خرید اینترنتی").forEach { kv ->
                typeRow.addView(chip(kv.second, type == kv.first) { type = kv.first; fillType() })
            }
        }
        fillType()
        f.put(typeRow, 4)

        f.put(tv("مبلغ — دقیقاً همان‌طور که در پیام نوشته شده", 13f, C.muted), 12)
        val amount = field("مثلاً 500,000")
        f.put(amount, 4)

        f.put(tv("واحد مبلغ در پیام", 13f, C.muted), 12)
        val unitRow = Flow(this)
        fun fillUnit() {
            unitRow.removeAllViews()
            unitRow.addView(chip("ریال", rial) { rial = true; fillUnit() })
            unitRow.addView(chip("تومان", !rial) { rial = false; fillUnit() })
        }
        fillUnit()
        f.put(unitRow, 4)

        f.put(tv("عبارت شناسایی (ثابت در همه پیام‌های این نوع)", 13f, C.muted), 12)
        val keyword = field("مثلاً برداشت پول")
        f.put(keyword, 4)

        f.put(tv("نام پذیرنده (اختیاری، مخصوص خرید)", 13f, C.muted), 12)
        val merchant = field("مثلاً اسنپ")
        f.put(merchant, 4)

        val result = tv("", 13f, C.muted)
        f.put(result, 12)

        fun fail(msg: String): Rule? { result.text = msg; result.setTextColor(C.red); return null }

        fun build(): Rule? {
            val s = sample.text.toString()
            val a = amount.text.toString()
            if (s.isBlank() || a.isBlank()) return fail("متن نمونه و مبلغ را بنویس")
            val kw = keyword.text.toString().trim().ifEmpty {
                when (type) { "withdraw" -> "برداشت"; "deposit" -> "واریز"; else -> "خرید" }
            }
            val r = Parser.learn(s, a, merchant.text.toString(), kw, type, rial)
                ?: return fail("این مبلغ داخل متن نمونه پیدا نشد؛ دقیقاً مثل پیام بنویسش")
            val m = Parser.matchRule(Parser.norm(s), r)
                ?: return fail("عبارت شناسایی در پیام نیست؛ یک عبارت از خود پیام بنویس")
            result.text = "✓ مبلغ شناسایی‌شده: " + Parser.fmt(m.second) +
                (if (m.third.isNotEmpty()) "\nپذیرنده: " + m.third else "") +
                "\nاگر مبلغ درست نیست، واحد (ریال/تومان) را بررسی کن."
            result.setTextColor(C.green)
            return r
        }

        val row = LinearLayout(this)
        row.put(pill("تست", C.chipBg, C.text) { build() }, 0, 0, 1f)
        row.put(pill("ذخیره") {
            val r = build() ?: return@pill
            db.addRule(r)
            db.unknown().forEach { pr -> if (Parser.matchRule(Parser.norm(pr.second), r) != null) db.delUnknown(pr.first) }
            Toast.makeText(this, "فرمت ذخیره شد", Toast.LENGTH_SHORT).show()
            finish()
        }, 0, 0, 1f, 8)
        f.put(row, 12)
        p.put(f, 12)

        setContentView(ScrollView(this).apply { setBackgroundColor(C.bg); addView(p) })
    }
}
