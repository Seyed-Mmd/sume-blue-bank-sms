package com.example.banksms

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

private val TUTORIAL = listOf(
    "۱) متن کامل یک پیامک واقعی بانک را در «نمونه پیامک» بچسبان (یا از لیست «شناخته نشدند» انتخاب کن).",
    "۲) مبلغ تراکنش را دقیقاً مثل پیام بنویس؛ مثلاً 500,000 (نه موجودی!). علامت منفی/مثبت کنار مبلغ مهم نیست و شماره کارت/حساب هم می‌تواند در هر پیام فرق کند.",
    "۳) نوع پیام، واحد مبلغ (ریال/تومان) و نام بانک را مشخص کن. برنامه همیشه به تومان ذخیره می‌کند.",
    "۴) «تحلیل خودکار» را بزن؛ برنامه عبارت شناسایی و متن اطراف مبلغ را خودش پیدا و تست می‌کند.",
    "۵) اگر لازم بود، فیلدهای «تنظیمات فرمت» را دستی عوض کن:",
    "   • عبارت شناسایی: یک عبارت ثابت که فقط در همین نوع پیام هست (مثل «برداشت پول»).",
    "   • متن قبل/بعد مبلغ: کلماتی که دقیقاً قبل و بعد از مبلغ می‌آیند (می‌تواند خالی باشد).",
    "   • پذیرنده (برای خرید): متنی که قبل/بعد از نام فروشگاه می‌آید.",
    "۶) «تست» را بزن؛ اگر مبلغ درست درآمد، ذخیره کن.",
    "",
    "نکته: برای هر نوع پیام یک فرمت جدا بساز (واریز، برداشت، خرید). پیامک‌های ناشناخته فقط روی همین گوشی نگه داشته می‌شوند (حداکثر ۱۲ تا)."
).joinToString("\n")

// افزودن یا ویرایش یک فرمت پیامک (extra: rule = شناسه برای ویرایش، sample = متن نمونه)
class RuleActivity : Activity() {
    private lateinit var db: Db
    private var type = "withdraw"
    private var rial = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        C.load(this); C.style(window)
        db = Db(this)
        val editId = intent.getLongExtra("rule", -1L)
        val old: Rule? = if (editId != -1L) db.rules().firstOrNull { it.id == editId } else null
        if (old != null) { type = old.type; rial = old.rial }

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        p.put(tv(if (old != null) "ویرایش فرمت پیامک" else "افزودن فرمت پیامک", 22f, C.text, true))

        // آموزش (قابل جمع شدن)
        val tut = card()
        val tutBody = tv(TUTORIAL, 13f, C.muted).apply {
            setLineSpacing(0f, 1.3f); visibility = if (old != null) View.GONE else View.VISIBLE
        }
        val tutHead = tv(if (old != null) "▸ آموزش" else "▾ آموزش", 16f, C.text, true)
        tutHead.setOnClickListener {
            val show = tutBody.visibility != View.VISIBLE
            tutBody.visibility = if (show) View.VISIBLE else View.GONE
            tutHead.text = if (show) "▾ آموزش" else "▸ آموزش"
        }
        tut.put(tutHead); tut.put(tutBody, 8)
        p.put(tut, 12)

        // ۱) نمونه
        val sampleF = field("متن کامل یک پیامک نمونه را اینجا بچسبان", intent.getStringExtra("sample") ?: "").apply {
            minLines = 4; gravity = Gravity.TOP or Gravity.START
        }
        val a = card()
        a.put(tv("۱) نمونه پیامک", 16f, C.text, true))
        val unk = db.unknown()
        if (unk.isNotEmpty()) {
            a.put(tv("پیامک‌های اخیر که شناخته نشدند — یکی را بزن:", 12f, C.muted), 6)
            val fl = Flow(this)
            unk.forEach { pr ->
                val txt = pr.second
                fl.addView(chip(txt.replace("\n", " ").take(26) + "…", false) { sampleF.setText(txt) })
            }
            a.put(fl, 6)
        }
        a.put(sampleF, 8)
        a.put(tv("مبلغ — دقیقاً همان‌طور که در پیام نوشته شده", 12f, C.muted), 10)
        val amountF = field("مثلاً 500,000")
        a.put(amountF, 4)
        a.put(tv("نام پذیرنده (اختیاری، مخصوص خرید)", 12f, C.muted), 10)
        val merchF = field("مثلاً اسنپ")
        a.put(merchF, 4)
        p.put(a, 12)

        // ۲) تنظیمات فرمت
        val f = card()
        f.put(tv("۲) تنظیمات فرمت", 16f, C.text, true))
        f.put(tv("با «تحلیل خودکار» پر می‌شود و قابل ویرایش است.", 12f, C.muted), 2)

        f.put(tv("نام بانک (برای نمایش و آمار)", 12f, C.muted), 10)
        val bankF = field("مثلاً بلو، ملی، ملت", old?.bank ?: "")
        f.put(bankF, 4)
        val banks = db.banks()
        if (banks.isNotEmpty()) {
            val bf = Flow(this)
            banks.forEach { n -> bf.addView(chip(n, false) { bankF.setText(n) }) }
            f.put(bf, 6)
        }

        f.put(tv("نوع پیام", 12f, C.muted), 10)
        val typeRow = Flow(this)
        fun fillType() {
            typeRow.removeAllViews()
            listOf("withdraw" to "برداشت", "deposit" to "واریز", "purchase" to "خرید اینترنتی").forEach { kv ->
                typeRow.addView(chip(kv.second, type == kv.first) { type = kv.first; fillType() })
            }
        }
        fillType()
        f.put(typeRow, 4)

        f.put(tv("واحد مبلغ در پیام", 12f, C.muted), 10)
        val unitRow = Flow(this)
        fun fillUnit() {
            unitRow.removeAllViews()
            unitRow.addView(chip("ریال", rial) { rial = true; fillUnit() })
            unitRow.addView(chip("تومان", !rial) { rial = false; fillUnit() })
        }
        fillUnit()
        f.put(unitRow, 4)

        f.put(tv("عبارت شناسایی (ثابت در همه پیام‌های این نوع)", 12f, C.muted), 10)
        val keywordF = field("مثلاً برداشت پول", old?.keyword ?: "")
        f.put(keywordF, 4)
        f.put(tv("متن قبل از مبلغ", 12f, C.muted), 10)
        val beforeF = field("می‌تواند خالی باشد", old?.before ?: "")
        f.put(beforeF, 4)
        f.put(tv("متن بعد از مبلغ", 12f, C.muted), 10)
        val afterF = field("مثلاً ریال از حساب", old?.after ?: "")
        f.put(afterF, 4)
        f.put(tv("پذیرنده — متن قبل از نام (مخصوص خرید)", 12f, C.muted), 10)
        val mBeforeF = field("می‌تواند خالی باشد", old?.mBefore ?: "")
        f.put(mBeforeF, 4)
        f.put(tv("پذیرنده — متن بعد از نام", 12f, C.muted), 10)
        val mAfterF = field("خالی = تا آخر همان خط", old?.mAfter ?: "")
        f.put(mAfterF, 4)

        val result = tv("", 13f, C.muted)
        f.put(result, 12)
        p.put(f, 12)

        fun fail(msg: String) { result.text = msg; result.setTextColor(C.red) }
        fun defKw() = when (type) { "withdraw" -> "برداشت"; "deposit" -> "واریز"; else -> "خرید" }

        fun fromFields(): Rule {
            val bank = bankF.text.toString().trim()
            return Rule(old?.id ?: 0L, Parser.ruleName(bank, type), bank, type, keywordF.text.toString().trim(),
                beforeF.text.toString().trim(), afterF.text.toString().trim(), rial,
                mBeforeF.text.toString().trim(), mAfterF.text.toString().trim(), old?.builtin ?: false, old?.enabled ?: true)
        }

        fun test(): Boolean {
            val s = sampleF.text.toString()
            if (s.isBlank()) { fail("برای تست، یک متن نمونه بچسبان"); return false }
            val m = Parser.matchRule(Parser.norm(s), fromFields())
            if (m == null) { fail("با این تنظیمات پیام شناخته نشد؛ عبارت شناسایی و متن قبل/بعد مبلغ را بررسی کن"); return false }
            result.text = "✓ مبلغ شناسایی‌شده: " + Parser.fmt(m.amount) +
                (if (m.merchant.isNotEmpty()) "\nپذیرنده: " + m.merchant else "") +
                "\nاگر مبلغ درست نیست، واحد (ریال/تومان) را بررسی کن."
            result.setTextColor(C.green)
            return true
        }

        fun analyze() {
            val s = sampleF.text.toString(); val am = amountF.text.toString()
            if (s.isBlank() || am.isBlank()) { fail("متن نمونه و مبلغ را بنویس"); return }
            val kw = keywordF.text.toString().trim().ifEmpty { defKw() }
            val r = Parser.learn(s, am, merchF.text.toString(), kw, type, rial, bankF.text.toString().trim())
            if (r == null) { fail("این مبلغ داخل متن نمونه پیدا نشد؛ دقیقاً مثل پیام بنویسش"); return }
            keywordF.setText(r.keyword); beforeF.setText(r.before); afterF.setText(r.after)
            mBeforeF.setText(r.mBefore); mAfterF.setText(r.mAfter)
            test()
        }

        val auto = pill("تحلیل خودکار", C.chipBg, C.text) { analyze() }
        a.put(auto, 12)

        val row = LinearLayout(this)
        row.put(pill("تست", C.chipBg, C.text) { test() }, 0, 0, 1f)
        row.put(pill("ذخیره") {
            val r = fromFields()
            if (r.keyword.isBlank()) { fail("عبارت شناسایی را بنویس"); return@pill }
            if (old == null || sampleF.text.isNotBlank()) { if (!test()) return@pill }
            if (old != null) db.updateRule(r) else db.addRule(r)
            db.unknown().forEach { pr -> if (Parser.matchRule(Parser.norm(pr.second), r) != null) db.delUnknown(pr.first) }
            toast("فرمت ذخیره شد")
            finish()
        }, 0, 0, 1f, 8)
        f.put(row, 12)

        setContentView(ScrollView(this).apply { setBackgroundColor(C.bg); isFillViewport = true; addView(centered(p)) })
    }
}
