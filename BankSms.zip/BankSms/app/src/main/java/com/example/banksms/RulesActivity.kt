package com.example.banksms

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

// مدیریت بانک‌ها و فرمت‌های پیامک
class RulesActivity : Activity() {
    private lateinit var db: Db

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        C.load(this); C.style(window)
        db = Db(this)
    }
    override fun onResume() { super.onResume(); render() }

    private fun typeColor(t: String) = when (t) { "deposit" -> C.green; "withdraw" -> C.red; else -> Color.parseColor("#F79009") }

    private fun render() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        p.put(tv("بانک‌ها و فرمت پیامک", 22f, C.text, true))
        p.put(tv("هر بانک چند فرمت دارد (واریز، برداشت، خرید). فرمت‌ها را ویرایش، غیرفعال یا حذف کن.", 13f, C.muted), 4)

        // آزمایش سریع یک پیامک
        val tc = card()
        tc.put(tv("آزمایش یک پیامک", 16f, C.text, true))
        tc.put(tv("پیامک را بچسبان تا ببینی کدام فرمت می‌خواندش.", 12f, C.muted), 2)
        val sample = field("متن پیامک").apply { minLines = 3; gravity = Gravity.TOP or Gravity.START }
        tc.put(sample, 8)
        val res = tv("", 13f, C.muted)
        tc.put(pill("بررسی", C.chipBg, C.text) {
            val s = sample.text.toString()
            if (s.isBlank()) { res.text = "متن را بنویس"; res.setTextColor(C.red); return@pill }
            val t = Parser.norm(s)
            val hit = db.rules().filter { it.enabled }.firstNotNullOfOrNull { r -> Parser.matchRule(t, r)?.let { m -> Pair(r, m) } }
            if (hit == null) {
                res.text = "هیچ فرمتی این پیام را نمی‌خواند. با «افزودن فرمت» بسازش."
                res.setTextColor(C.red)
            } else {
                val r = hit.first; val m = hit.second
                res.text = "✓ فرمت: ${r.name}\nنوع: ${Parser.label(m.type)}  •  مبلغ: ${Parser.fmt(m.amount)}" +
                    (if (m.bank.isNotEmpty()) "  •  بانک: ${m.bank}" else "") +
                    (if (m.merchant.isNotEmpty()) "\nپذیرنده: ${m.merchant}" else "")
                res.setTextColor(C.green)
            }
        }, 8)
        tc.put(res, 8)
        p.put(tc, 12)

        val top = LinearLayout(this)
        top.put(pill("＋ افزودن فرمت") { startActivity(Intent(this, RuleActivity::class.java)) }, 0, 0, 1f)
        top.put(pill("بازگردانی پیش‌فرض‌ها", C.chipBg, C.text) {
            confirm("فرمت‌های پیش‌فرض بلو به حالت اولیه برمی‌گردند (تغییرات‌شان از بین می‌رود). ادامه؟") { db.resetDefaults(); render() }
        }, 0, 0, 1f, 8)
        p.put(top, 12)

        // پیامک‌های شناخته‌نشده
        val unk = db.unknown()
        if (unk.isNotEmpty()) {
            val u = card()
            u.put(tv("پیامک‌های مالی شناخته‌نشده", 16f, C.text, true))
            u.put(tv("یکی را بزن تا برایش فرمت بسازی.", 12f, C.muted), 2)
            val fl = Flow(this)
            unk.forEach { pr ->
                val txt = pr.second
                fl.addView(chip(txt.replace("\n", " ").take(26) + "…", false) {
                    startActivity(Intent(this, RuleActivity::class.java).putExtra("sample", txt))
                })
            }
            u.put(fl, 8)
            p.put(u, 12)
        }

        // فرمت‌ها به تفکیک بانک
        db.rules().groupBy { it.bank.ifEmpty { "بدون نام بانک" } }.forEach { (bank, list) ->
            val c = card()
            c.put(tv("🏦 $bank", 17f, C.text, true))
            list.forEachIndexed { i, r ->
                if (i > 0) c.put(View(this).apply { setBackgroundColor(C.chipBg) }, 12, -1, 0f, 0, 1)
                c.put(ruleRow(r), 10)
            }
            p.put(c, 12)
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(C.bg); isFillViewport = true; addView(centered(p)) })
    }

    private fun ruleRow(r: Rule): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; alpha = if (r.enabled) 1f else 0.55f }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.put(tv(Parser.label(r.type), 12f, Color.WHITE, true).apply {
            background = shape(typeColor(r.type), 10); setPadding(dp(10), dp(4), dp(10), dp(4))
        }, 0, -2)
        head.put(tv("«${r.keyword}»", 14f, C.text, true), 0, 0, 1f, 10)
        box.put(head)
        val unit = if (r.rial) "ریال" else "تومان"
        box.put(tv("واحد مبلغ در پیام: $unit" + (if (r.builtin) "  •  پیش‌فرض" else ""), 12f, C.muted), 4)
        val actions = Flow(this)
        actions.addView(chip("ویرایش", false) { startActivity(Intent(this, RuleActivity::class.java).putExtra("rule", r.id)) })
        actions.addView(chip(if (r.enabled) "فعال ✓" else "غیرفعال", r.enabled) { db.setRuleEnabled(r.id, !r.enabled); render() })
        actions.addView(chip("کپی", false) { db.addRule(r.copy(id = 0, builtin = false, name = r.name + " (کپی)")); render() })
        actions.addView(chip("حذف", false) { confirm("این فرمت حذف شود؟") { db.delRule(r.id); render() } })
        box.put(actions, 8)
        return box
    }
}
