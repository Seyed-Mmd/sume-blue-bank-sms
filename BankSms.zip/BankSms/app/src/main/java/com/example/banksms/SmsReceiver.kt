package com.example.banksms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val (type, amount, merchant) = Parser.parse(body) ?: return
        Db(c).add(type, amount, merchant)
        Launcher.startService(c)
        // اگر همین الان با گوشی کار می‌کنی، فوری نشان بده؛ وگرنه منتظر باز شدن قفل می‌ماند
        if (Launcher.usingPhone(c)) Launcher.showPopupIfPending(c)
    }
}
