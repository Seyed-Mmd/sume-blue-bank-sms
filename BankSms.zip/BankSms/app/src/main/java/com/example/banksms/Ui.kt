package com.example.banksms

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object C {
    var dark = false
    var bg = Color.parseColor("#F3F5FA")
    var card = Color.WHITE
    var primary = Color.parseColor("#4263EB")
    var hdrA = Color.parseColor("#4263EB")
    var hdrB = Color.parseColor("#7048E8")
    var green = Color.parseColor("#12B76A")
    var red = Color.parseColor("#F04438")
    var redBg = Color.parseColor("#FEE4E2")
    var text = Color.parseColor("#101828")
    var muted = Color.parseColor("#667085")
    var chipBg = Color.parseColor("#EEF1F6")
    var input = Color.parseColor("#F2F4F7")
    val palette = intArrayOf(
        Color.parseColor("#4263EB"), Color.parseColor("#12B76A"), Color.parseColor("#F79009"),
        Color.parseColor("#7048E8"), Color.parseColor("#F04438"), Color.parseColor("#0BA5EC"), Color.parseColor("#EE46BC")
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    // 0 = خودکار (سیستم)، 1 = روشن، 2 = تاریک
    fun mode(ctx: Context): Int = prefs(ctx).getInt("theme", 0)
    fun setMode(ctx: Context, m: Int) { prefs(ctx).edit().putInt("theme", m).apply() }

    fun load(ctx: Context) {
        val sys = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val m = mode(ctx)
        dark = if (m == 0) sys else m == 2
        if (dark) {
            bg = Color.parseColor("#0E1117"); card = Color.parseColor("#1A1F2B"); primary = Color.parseColor("#5B7BFF")
            hdrA = Color.parseColor("#3B54C9"); hdrB = Color.parseColor("#5B3DB8")
            green = Color.parseColor("#32D583"); red = Color.parseColor("#F97066"); redBg = Color.parseColor("#4A1D1D")
            text = Color.parseColor("#F2F4F7"); muted = Color.parseColor("#98A2B3")
            chipBg = Color.parseColor("#2A3140"); input = Color.parseColor("#252C3A")
        } else {
            bg = Color.parseColor("#F3F5FA"); card = Color.WHITE; primary = Color.parseColor("#4263EB")
            hdrA = Color.parseColor("#4263EB"); hdrB = Color.parseColor("#7048E8")
            green = Color.parseColor("#12B76A"); red = Color.parseColor("#F04438"); redBg = Color.parseColor("#FEE4E2")
            text = Color.parseColor("#101828"); muted = Color.parseColor("#667085")
            chipBg = Color.parseColor("#EEF1F6"); input = Color.parseColor("#F2F4F7")
        }
    }

    // رنگ نوار وضعیت و نوار پایین سیستم
    fun style(w: Window) {
        w.statusBarColor = bg
        w.navigationBarColor = card
        var f = w.decorView.systemUiVisibility
        f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        w.decorView.systemUiVisibility = f
    }
}

// فونت وزیرمتن (معمولی / ضخیم)
fun Context.vazir(bold: Boolean = false): Typeface =
    try { Typeface.create(resources.getFont(R.font.vazirmatn), if (bold) Typeface.BOLD else Typeface.NORMAL) }
    catch (_: Exception) { Typeface.defaultFromStyle(if (bold) Typeface.BOLD else Typeface.NORMAL) }

// انیمیشن ساده فشردن: دکمه هنگام لمس کمی کوچک می‌شود
@android.annotation.SuppressLint("ClickableViewAccessibility")
fun <T : View> T.pressable(): T {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        false
    }
    return this
}

// ظاهر شدن نرم یک صفحه (محو شدن + کمی حرکت از پایین)
fun View.fadeIn(ms: Long = 220) {
    alpha = 0f; translationY = 12f * resources.displayMetrics.density
    animate().alpha(1f).translationY(0f).setDuration(ms).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
}

fun Context.dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

fun Context.shape(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat()
}

fun Context.tv(s: String, size: Float = 15f, color: Int = C.text, bold: Boolean = false): TextView = TextView(this).apply {
    text = s; textSize = size; setTextColor(color)
    typeface = vazir(bold)
}

fun Context.card(pad: Int = 16): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = shape(C.card, 18)
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    elevation = dp(2).toFloat()
}

fun Context.pill(s: String, bg: Int = C.primary, fg: Int = Color.WHITE, onClick: () -> Unit): TextView = TextView(this).apply {
    text = s; textSize = 15f; setTextColor(fg); typeface = vazir(true)
    gravity = Gravity.CENTER; background = shape(bg, 24)
    setPadding(dp(18), dp(12), dp(18), dp(12))
    minimumHeight = dp(48)
    setOnClickListener { onClick() }
    pressable()
}

fun Context.chip(s: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
    text = s; textSize = 13f; typeface = vazir(false)
    setTextColor(if (selected) Color.WHITE else C.text)
    background = shape(if (selected) C.primary else C.chipBg, 20)
    setPadding(dp(14), dp(10), dp(14), dp(10))
    minimumHeight = dp(40); gravity = Gravity.CENTER_VERTICAL
    setOnClickListener { onClick() }
    pressable()
}

fun Context.field(hint: String, value: String = "", number: Boolean = false): EditText = EditText(this).apply {
    this.hint = hint; setText(value); textSize = 15f; typeface = vazir(false)
    setTextColor(C.text); setHintTextColor(C.muted)
    background = shape(C.input, 12)
    setPadding(dp(14), dp(12), dp(14), dp(12))
    if (number) inputType = InputType.TYPE_CLASS_NUMBER
}

// افزودن view به LinearLayout با فاصله از بالا (dp)، عرض، وزن، فاصله شروع و ارتفاع
fun LinearLayout.put(v: View, top: Int = 0, w: Int = -1, weight: Float = 0f, start: Int = 0, h: Int = -2): View {
    val k = resources.displayMetrics.density
    val lp = LinearLayout.LayoutParams(w, if (h > 0) (h * k).toInt() else h, weight)
    lp.topMargin = (top * k).toInt()
    lp.marginStart = (start * k).toInt()
    addView(v, lp)
    return v
}

fun EditText.onText(f: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { f(s.toString()) }
    })
}

// چیدمان «چندخطی» برای چیپ‌ها
class Flow(c: Context) : ViewGroup(c) {
    private val gap = (8 * c.resources.displayMetrics.density).toInt()

    override fun onMeasure(ws: Int, hs: Int) {
        val maxW = View.MeasureSpec.getSize(ws)
        var x = 0; var y = 0; var rowH = 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            v.measure(
                View.MeasureSpec.makeMeasureSpec(maxW, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            if (x > 0 && x + v.measuredWidth > maxW) { x = 0; y += rowH + gap; rowH = 0 }
            x += v.measuredWidth + gap
            rowH = maxOf(rowH, v.measuredHeight)
        }
        setMeasuredDimension(maxW, y + rowH)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
        var x = 0; var y = 0; var rowH = 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val cw = v.measuredWidth; val chh = v.measuredHeight
            if (x > 0 && x + cw > w) { x = 0; y += rowH + gap; rowH = 0 }
            val left = if (rtl) w - x - cw else x
            v.layout(left, y, left + cw, y + chh)
            x += cw + gap
            rowH = maxOf(rowH, chh)
        }
    }
}

// متن تک‌خطی که برای جا شدن در عرض، خودکار کوچک می‌شود
fun TextView.fit(minSp: Int, maxSp: Int) {
    maxLines = 1
    setAutoSizeTextTypeUniformWithConfiguration(minSp, maxSp, 1, TypedValue.COMPLEX_UNIT_SP)
}

// نگه‌دارنده‌ای که فرزندش را با حداکثر عرض مشخص و دقیقاً وسط قرار می‌دهد.
// عرض را از خودِ پنجره می‌گیرد (نه از اندازه صفحه نمایش)، پس هیچ‌وقت کج یا بیرون‌زده نمی‌شود.
class MaxWidth(c: Context, private val maxPx: Int) : ViewGroup(c) {
    override fun onMeasure(ws: Int, hs: Int) {
        val mode = View.MeasureSpec.getMode(ws)
        val w = if (mode == View.MeasureSpec.UNSPECIFIED) maxPx else View.MeasureSpec.getSize(ws)
        val cw = minOf(w, maxPx)
        val v = getChildAt(0)
        if (v == null) { setMeasuredDimension(w, 0); return }
        v.measure(
            View.MeasureSpec.makeMeasureSpec(cw, View.MeasureSpec.EXACTLY),
            getChildMeasureSpec(hs, 0, v.layoutParams.height)
        )
        setMeasuredDimension(w, resolveSize(v.measuredHeight, hs))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val v = getChildAt(0) ?: return
        val left = ((r - l) - v.measuredWidth) / 2
        v.layout(left, 0, left + v.measuredWidth, v.measuredHeight)
    }
}

// محتوا را وسط صفحه و با حداکثر عرض نگه می‌دارد (تبلت/حالت افقی)
fun Context.centered(content: View, maxDp: Int = 640): View =
    MaxWidth(this, dp(maxDp)).apply {
        addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

// بعد از ساخته‌شدن دوباره صفحه، اسکرول را به همان جای قبلی برمی‌گرداند
fun android.widget.ScrollView.restoreScroll(y: Int) {
    if (y <= 0) return
    viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
        override fun onPreDraw(): Boolean {
            viewTreeObserver.removeOnPreDrawListener(this)
            scrollTo(0, y)
            return true
        }
    })
}

// دیالوگ هماهنگ با تم روشن/تاریک
fun Context.dialog(): android.app.AlertDialog.Builder = android.app.AlertDialog.Builder(this,
    if (C.dark) R.style.DialogDark else R.style.DialogLight)

fun Context.confirm(msg: String, ok: () -> Unit) {
    dialog().setMessage(msg).setPositiveButton("بله") { _, _ -> ok() }.setNegativeButton("خیر", null).show()
}

fun Context.toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_LONG).show()
