package com.example.banksms

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val bg = Color.parseColor("#F3F5FA")
    val card = Color.WHITE
    val primary = Color.parseColor("#4263EB")
    val green = Color.parseColor("#12B76A")
    val red = Color.parseColor("#F04438")
    val redBg = Color.parseColor("#FEE4E2")
    val text = Color.parseColor("#101828")
    val muted = Color.parseColor("#667085")
    val chipBg = Color.parseColor("#EEF1F6")
    val input = Color.parseColor("#F2F4F7")
    val palette = intArrayOf(
        Color.parseColor("#4263EB"), Color.parseColor("#12B76A"), Color.parseColor("#F79009"),
        Color.parseColor("#7048E8"), Color.parseColor("#F04438"), Color.parseColor("#0BA5EC"), Color.parseColor("#EE46BC")
    )
}

fun Context.dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

fun Context.shape(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat()
}

fun Context.tv(s: String, size: Float = 15f, color: Int = C.text, bold: Boolean = false): TextView = TextView(this).apply {
    text = s; textSize = size; setTextColor(color)
    if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.card(pad: Int = 16): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = shape(C.card, 18)
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    elevation = dp(2).toFloat()
}

fun Context.pill(s: String, bg: Int = C.primary, fg: Int = Color.WHITE, onClick: () -> Unit): TextView = TextView(this).apply {
    text = s; textSize = 15f; setTextColor(fg); setTypeface(typeface, Typeface.BOLD)
    gravity = Gravity.CENTER; background = shape(bg, 24)
    setPadding(dp(18), dp(12), dp(18), dp(12))
    setOnClickListener { onClick() }
}

fun Context.chip(s: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
    text = s; textSize = 13f
    setTextColor(if (selected) Color.WHITE else C.text)
    background = shape(if (selected) C.primary else C.chipBg, 20)
    setPadding(dp(14), dp(8), dp(14), dp(8))
    setOnClickListener { onClick() }
}

fun Context.field(hint: String, value: String = "", number: Boolean = false): EditText = EditText(this).apply {
    this.hint = hint; setText(value); textSize = 15f
    setTextColor(C.text); setHintTextColor(C.muted)
    background = shape(C.input, 12)
    setPadding(dp(14), dp(12), dp(14), dp(12))
    if (number) inputType = InputType.TYPE_CLASS_NUMBER
}

// افزودن view به LinearLayout با فاصله از بالا (dp)، عرض، وزن، فاصله شروع و ارتفاع
fun LinearLayout.put(v: View, top: Int = 0, w: Int = -1, weight: Float = 0f, start: Int = 0, h: Int = -2): View {
    val k = resources.displayMetrics.density
    val lp = LinearLayout.LayoutParams(w, if (h > 0) (h * k).toInt() else h, weight)
    lp.topMargin = (top * k).toInt()
    lp.marginStart = (start * k).toInt()
    addView(v, lp)
    return v
}

fun EditText.onText(f: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { f(s.toString()) }
    })
}

// چیدمان «چندخطی» برای چیپ‌ها
class Flow(c: Context) : ViewGroup(c) {
    private val gap = (8 * c.resources.displayMetrics.density).toInt()

    override fun onMeasure(ws: Int, hs: Int) {
        val maxW = View.MeasureSpec.getSize(ws)
        var x = 0; var y = 0; var rowH = 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            v.measure(
                View.MeasureSpec.makeMeasureSpec(maxW, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            if (x > 0 && x + v.measuredWidth > maxW) { x = 0; y += rowH + gap; rowH = 0 }
            x += v.measuredWidth + gap
            rowH = maxOf(rowH, v.measuredHeight)
        }
        setMeasuredDimension(maxW, y + rowH)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
        var x = 0; var y = 0; var rowH = 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val cw = v.measuredWidth; val chh = v.measuredHeight
            if (x > 0 && x + cw > w) { x = 0; y += rowH + gap; rowH = 0 }
            val left = if (rtl) w - x - cw else x
            v.layout(left, y, left + cw, y + chh)
            x += cw + gap
            rowH = maxOf(rowH, chh)
        }
    }
}
