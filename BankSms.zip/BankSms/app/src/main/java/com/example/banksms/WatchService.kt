package com.example.banksms

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

// فقط برای شنیدن «باز شدن قفل گوشی» (این رویداد را فقط سرویس زنده می‌تواند بگیرد)
class WatchService : Service() {
    private val unlock = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { Launcher.showPopupIfPending(c) }
    }
    override fun onCreate() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("svc", "سرویس ثبت تراکنش", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "svc").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("ثبت تراکنش فعال است").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        val f = IntentFilter(Intent.ACTION_USER_PRESENT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(unlock, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(unlock, f)
    }
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onDestroy() { unregisterReceiver(unlock) }
    override fun onBind(i: Intent?): IBinder? = null
}
